using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class OlcuBirimiManager : IOlcuBirimiService
{
    private readonly IUnitOfWork _unitOfWork;
    public OlcuBirimiManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(OlcuBirimi entity)
    {
        _unitOfWork.OlcuBirimis.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(OlcuBirimi entity)
    {
        _unitOfWork.OlcuBirimis.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<OlcuBirimi>> GetAktif()
    {
        return await  _unitOfWork.OlcuBirimis.GetAktif();
    }
    public async Task<List<OlcuBirimi>> GetAll()
    {
        return await _unitOfWork.OlcuBirimis.GetAll();
    }
    public async Task<OlcuBirimi> GetById(int id)
    {
        return await _unitOfWork.OlcuBirimis.GetById(id);
    }
    public void Update(OlcuBirimi entity)
    {
        _unitOfWork.OlcuBirimis.Update(entity);
        _unitOfWork.Save();

    }
}