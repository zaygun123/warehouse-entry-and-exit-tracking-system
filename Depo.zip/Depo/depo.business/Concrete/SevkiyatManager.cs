using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class SevkiyatManager : ISevkiyatService
{
    private readonly IUnitOfWork _unitOfWork;
    public SevkiyatManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Sevkiyat entity)
    {
        _unitOfWork.Sevkiyats.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Sevkiyat entity)
    {
        _unitOfWork.Sevkiyats.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Sevkiyat>> GetAktif()
    {
        return await  _unitOfWork.Sevkiyats.GetAktif();
    }
    public async Task<List<Sevkiyat>> GetAll()
    {
        return await _unitOfWork.Sevkiyats.GetAll();
    }
    public async Task<Sevkiyat> GetById(int id)
    {
        return await _unitOfWork.Sevkiyats.GetById(id);
    }

    public async Task<Sevkiyat> GetFilterSiparis(int id)
    {
        return await _unitOfWork.Sevkiyats.GetFilterSiparis(id);
    }

    public void Update(Sevkiyat entity)
    {
        _unitOfWork.Sevkiyats.Update(entity);
        _unitOfWork.Save();

    }
}