using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class StokManager : IStokService
{
    private readonly IUnitOfWork _unitOfWork;
    public StokManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Stok entity)
    {
        _unitOfWork.Stoks.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Stok entity)
    {
        _unitOfWork.Stoks.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Stok>> GetAktif()
    {
        return await  _unitOfWork.Stoks.GetAktif();
    }
    public async Task<List<Stok>> GetAll()
    {
        return await _unitOfWork.Stoks.GetAll();
    }
    public async Task<Stok> GetById(int id)
    {
        return await _unitOfWork.Stoks.GetById(id);
    }

    public async Task<List<Stok>> GetFilterSiparis(int? id)
    {
        return await _unitOfWork.Stoks.GetFilterSiparis(id);
    }


    public async Task<List<Stok>> GetStoksByRafId(int? id)
    {
        return await _unitOfWork.Stoks.GetStoksByRafId(id);
    }

    public void Update(Stok entity)
    {
        _unitOfWork.Stoks.Update(entity);
        _unitOfWork.Save();

    }
}