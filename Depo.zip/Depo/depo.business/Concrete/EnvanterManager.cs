using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class EnvanterManager : IEnvanterService
{
    private readonly IUnitOfWork _unitOfWork;
    public EnvanterManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Envanter entity)
    {
        _unitOfWork.Envanters.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Envanter entity)
    {
        _unitOfWork.Envanters.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Envanter>> GetAktif()
    {
        return await  _unitOfWork.Envanters.GetAktif();
    }
    public async Task<List<Envanter>> GetAll()
    {
        return await _unitOfWork.Envanters.GetAll();
    }
    public async Task<Envanter> GetById(int id)
    {
        return await _unitOfWork.Envanters.GetById(id);
    }

    public async Task<List<Envanter>> GetFilterUrun(int? id)
    {
        return await _unitOfWork.Envanters.GetFilterUrun(id);
    }

    public void Update(Envanter entity)
    {
        _unitOfWork.Envanters.Update(entity);
        _unitOfWork.Save();

    }
}