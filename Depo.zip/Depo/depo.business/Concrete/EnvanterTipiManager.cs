using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class EnvanterTipiManager : IEnvanterTipiService
{
    private readonly IUnitOfWork _unitOfWork;
    public EnvanterTipiManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(EnvanterTipi entity)
    {
        _unitOfWork.EnvanterTipis.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(EnvanterTipi entity)
    {
        _unitOfWork.EnvanterTipis.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<EnvanterTipi>> GetAktif()
    {
        return await  _unitOfWork.EnvanterTipis.GetAktif();
    }
    public async Task<List<EnvanterTipi>> GetAll()
    {
        return await _unitOfWork.EnvanterTipis.GetAll();
    }
    public async Task<EnvanterTipi> GetById(int id)
    {
        return await _unitOfWork.EnvanterTipis.GetById(id);
    }
    public void Update(EnvanterTipi entity)
    {
        _unitOfWork.EnvanterTipis.Update(entity);
        _unitOfWork.Save();

    }
}