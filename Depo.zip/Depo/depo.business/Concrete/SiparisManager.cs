using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class SiparisManager : ISiparisService
{
    private readonly IUnitOfWork _unitOfWork;
    public SiparisManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Siparis entity)
    {
        _unitOfWork.Siparises.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Siparis entity)
    {
        _unitOfWork.Siparises.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Siparis>> GetAktif()
    {
        return await  _unitOfWork.Siparises.GetAktif();
    }
    public async Task<List<Siparis>> GetAll()
    {
        return await _unitOfWork.Siparises.GetAll();
    }
    public async Task<Siparis> GetById(int id)
    {
        return await _unitOfWork.Siparises.GetById(id);
    }

    public Task UpdateGetWithStok(Siparis entity, List<int> stok)
    {
        return _unitOfWork.Siparises.UpdateGetWithStok(entity,stok);
    }

    public void Update(Siparis entity)
    {
        _unitOfWork.Siparises.Update(entity);
        _unitOfWork.Save();

    }

    public async Task<List<Siparis>> GetFilterSevkiyat(int? id)
    {
        return await _unitOfWork.Siparises.GetFilterSevkiyat(id);
    }

    public async Task<Siparis> GetSiparisWithStok(int id)
    {
        return await _unitOfWork.Siparises.GetSiparisWithStok(id);
    }
}