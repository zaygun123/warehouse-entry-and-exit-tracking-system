using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class DepoManager : IDepoService
{
    private readonly IUnitOfWork _unitOfWork;
    public DepoManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Depo entity)
    {
        _unitOfWork.Depos.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Depo entity)
    {
        _unitOfWork.Depos.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Depo>> GetAktif()
    {
        return await  _unitOfWork.Depos.GetAktif();
    }
    public async Task<List<Depo>> GetAll()
    {
        return await _unitOfWork.Depos.GetAll();
    }
    public async Task<Depo> GetById(int id)
    {
        return await _unitOfWork.Depos.GetById(id);
    }

    public async Task<Depo> GetDepoWithTedarikci(int id)
    {
        return await _unitOfWork.Depos.GetDepoWithTedarikci(id);
    }

    public async Task<Depo> GetFilterPersonel(int id)
    {
        return await _unitOfWork.Depos.GetFilterPersonel(id);
    }

    public void Update(Depo entity)
    {
        _unitOfWork.Depos.Update(entity);
        _unitOfWork.Save();

    }

    public async Task UpdateGetWithTedarikci(Depo entity,List<int> tedarikci){
        await _unitOfWork.Depos.UpdateGetWithTedarikci(entity,tedarikci);

    }
}