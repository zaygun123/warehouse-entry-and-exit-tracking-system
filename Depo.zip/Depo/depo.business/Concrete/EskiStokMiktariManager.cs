using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class EskiStokMiktariManager : IEskiStokMiktariService
{
    private readonly IUnitOfWork _unitOfWork;
    public EskiStokMiktariManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(EskiStokMiktari entity)
    {
        _unitOfWork.EskiStokMiktaris.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(EskiStokMiktari entity)
    {
        _unitOfWork.EskiStokMiktaris.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<EskiStokMiktari>> GetAktif()
    {
        return await  _unitOfWork.EskiStokMiktaris.GetAktif();
    }
    public async Task<List<EskiStokMiktari>> GetAll()
    {
        return await _unitOfWork.EskiStokMiktaris.GetAll();
    }
    public async Task<EskiStokMiktari> GetById(int id)
    {
        return await _unitOfWork.EskiStokMiktaris.GetById(id);
    }

    public async Task<List<EskiStokMiktari>> GetsStokMiktariByStokId(int? stokId)
    {
        return await _unitOfWork.EskiStokMiktaris.GetsStokMiktariByStokId(stokId);
    }

    public void Update(EskiStokMiktari entity)
    {
        _unitOfWork.EskiStokMiktaris.Update(entity);
        _unitOfWork.Save();

    }
}