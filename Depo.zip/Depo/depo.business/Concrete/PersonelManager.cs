using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class PersonelManager : IPersonelService
{
    private readonly IUnitOfWork _unitOfWork;
    public PersonelManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Personel entity)
    {
        _unitOfWork.Personels.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Personel entity)
    {
        _unitOfWork.Personels.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Personel>> GetAktif()
    {
        return await  _unitOfWork.Personels.GetAktif();
    }
    public async Task<List<Personel>> GetAll()
    {
        return await _unitOfWork.Personels.GetAll();
    }
    public async Task<Personel> GetById(int id)
    {
        return await _unitOfWork.Personels.GetById(id);
    }

    public async Task<Personel> GetFilterStokHareketleri(int id)
    {
        return await _unitOfWork.Personels.GetFilterStokHareketleri(id);
    }

    public void Update(Personel entity)
    {
        _unitOfWork.Personels.Update(entity);
        _unitOfWork.Save();

    }
}