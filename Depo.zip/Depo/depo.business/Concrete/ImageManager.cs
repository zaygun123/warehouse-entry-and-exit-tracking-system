using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class ImageManager : IImageService
{
    private readonly IUnitOfWork _unitOfWork;
    public ImageManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Image entity)
    {
        _unitOfWork.Images.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Image entity)
    {
        _unitOfWork.Images.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Image>> GetAktif()
    {
        return await  _unitOfWork.Images.GetAktif();
    }
    public async Task<List<Image>> GetAll()
    {
        return await _unitOfWork.Images.GetAll();
    }
    public async Task<Image> GetById(int id)
    {
        return await _unitOfWork.Images.GetById(id);
    }

    public async Task<List<Image>> GetFilterUrun(int? id)
    {
        return await _unitOfWork.Images.GetFilterUrun(id);
    }

    public void Update(Image entity)
    {
        _unitOfWork.Images.Update(entity);
        _unitOfWork.Save();

    }
}