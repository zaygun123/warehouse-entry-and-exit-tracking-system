using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class UrunManager : IUrunService
{
    private readonly IUnitOfWork _unitOfWork;
    public UrunManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Urun entity)
    {
        _unitOfWork.Uruns.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Urun entity)
    {
        _unitOfWork.Uruns.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Urun>> GetAktif()
    {
        return await  _unitOfWork.Uruns.GetAktif();
    }
    public async Task<List<Urun>> GetAll()
    {
        return await _unitOfWork.Uruns.GetAll();
    }
    public async Task<Urun> GetById(int id)
    {
        return await _unitOfWork.Uruns.GetById(id);
    }

    public async Task<Urun> GetUrunWithEnvanter(int id)
    {
        return await _unitOfWork.Uruns.GetUrunWithEnvanter(id);
    }

    public void Update(Urun entity)
    {
        _unitOfWork.Uruns.Update(entity);
        _unitOfWork.Save();

    }

    public async Task UpdateGetWithEnvanter(Urun entity, List<int> envanter)
    {
        await _unitOfWork.Uruns.UpdateGetWithEnvanter(entity,envanter);
    }
}