using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class TedarikciManager : ITedarikciService
{
    private readonly IUnitOfWork _unitOfWork;
    public TedarikciManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Tedarikci entity)
    {
        _unitOfWork.Tedarikcis.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Tedarikci entity)
    {
        _unitOfWork.Tedarikcis.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Tedarikci>> GetAktif()
    {
        return await  _unitOfWork.Tedarikcis.GetAktif();
    }
    public async Task<List<Tedarikci>> GetAll()
    {
        return await _unitOfWork.Tedarikcis.GetAll();
    }
    public async Task<Tedarikci> GetById(int id)
    {
        return await _unitOfWork.Tedarikcis.GetById(id);
    }

    public async Task<List<Tedarikci>> GetFilterDepo(int? id)
    {
        return await _unitOfWork.Tedarikcis.GetFilterDepo(id);
    }

    public void Update(Tedarikci entity)
    {
        _unitOfWork.Tedarikcis.Update(entity);
        _unitOfWork.Save();

    }
}