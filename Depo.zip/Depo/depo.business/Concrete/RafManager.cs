using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class RafManager : IRafService
{
    private readonly IUnitOfWork _unitOfWork;
    public RafManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Raf entity)
    {
        _unitOfWork.Rafs.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Raf entity)
    {
        _unitOfWork.Rafs.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Raf>> GetAktif()
    {
        return await  _unitOfWork.Rafs.GetAktif();
    }
    public async Task<List<Raf>> GetAll()
    {
        return await _unitOfWork.Rafs.GetAll();
    }
    public async Task<Raf> GetById(int id)
    {
        return await _unitOfWork.Rafs.GetById(id);
    }

    public async Task<Raf> GetFilterStok(int id)
    {
        return await _unitOfWork.Rafs.GetFilterStok(id);
    }

    public async Task<List<Raf>> GetRafsByDepoId(int? id)
    {
        return await _unitOfWork.Rafs.GetRafsByDepoId(id);
    }

    public void Update(Raf entity)
    {
        _unitOfWork.Rafs.Update(entity);
        _unitOfWork.Save();

    }
}