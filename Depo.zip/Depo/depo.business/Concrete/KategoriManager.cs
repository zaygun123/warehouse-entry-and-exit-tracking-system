using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class KategoriManager : IKategoriService
{
    private readonly IUnitOfWork _unitOfWork;
    public KategoriManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Kategori entity)
    {
        _unitOfWork.Kategoris.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Kategori entity)
    {
        _unitOfWork.Kategoris.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Kategori>> GetAktif()
    {
        return await  _unitOfWork.Kategoris.GetAktif();
    }
    public async Task<List<Kategori>> GetAll()
    {
        return await _unitOfWork.Kategoris.GetAll();
    }
    public async Task<Kategori> GetById(int id)
    {
        return await _unitOfWork.Kategoris.GetById(id);
    }

    public async Task<Kategori> GetFilterUrun(int id)
    {
        return await _unitOfWork.Kategoris.GetFilterUrun(id);
    }

    public void Update(Kategori entity)
    {
        _unitOfWork.Kategoris.Update(entity);
        _unitOfWork.Save();

    }
}