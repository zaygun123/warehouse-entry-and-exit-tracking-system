using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class MusteriManager : IMusteriService
{
    private readonly IUnitOfWork _unitOfWork;
    public MusteriManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(Musteri entity)
    {
        _unitOfWork.Musteris.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(Musteri entity)
    {
        _unitOfWork.Musteris.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<Musteri>> GetAktif()
    {
        return await  _unitOfWork.Musteris.GetAktif();
    }
    public async Task<List<Musteri>> GetAll()
    {
        return await _unitOfWork.Musteris.GetAll();
    }
    public async Task<Musteri> GetById(int id)
    {
        return await _unitOfWork.Musteris.GetById(id);
    }

    public async Task<Musteri> GetFilterSiparis(int id)
    {
        return await _unitOfWork.Musteris.GetFilterSiparis(id);
    }

    public void Update(Musteri entity)
    {
        _unitOfWork.Musteris.Update(entity);
        _unitOfWork.Save();

    }
}