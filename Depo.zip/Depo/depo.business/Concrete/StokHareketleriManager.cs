using System.Collections.Generic;
using System.Threading.Tasks;
using depo.business.Abstract;
using depo.data.Abstract;
using depo.entity;

namespace depo.business.Concrete;
public class StokHareketleriManager : IStokHareketleriService
{
    private readonly IUnitOfWork _unitOfWork;
    public StokHareketleriManager(IUnitOfWork unitOfWork)
    {
        _unitOfWork=unitOfWork;
    }
    public void Create(StokHareketleri entity)
    {
        _unitOfWork.StokHareketleris.Create(entity);
        _unitOfWork.Save();
    }
    public void Delete(StokHareketleri entity)
    {
        _unitOfWork.StokHareketleris.Delete(entity);
        _unitOfWork.Save();
    }
    public async Task<List<StokHareketleri>> GetAktif()
    {
        return await  _unitOfWork.StokHareketleris.GetAktif();
    }
    public async Task<List<StokHareketleri>> GetAll()
    {
        return await _unitOfWork.StokHareketleris.GetAll();
    }
    public async Task<StokHareketleri> GetById(int id)
    {
        return await _unitOfWork.StokHareketleris.GetById(id);
    }

    public async Task<List<StokHareketleri>> GetStokHareketisByStokId(int? id)
    {
        return await _unitOfWork.StokHareketleris.GetStokHareketisByStokId(id);
    }

    public async Task<List<StokHareketleri>> GetStokHareketlerisByPersonelId(int? id)
    {
        return await _unitOfWork.StokHareketleris.GetStokHareketlerisByPersonelId(id);
    }

    public void Update(StokHareketleri entity)
    {
        _unitOfWork.StokHareketleris.Update(entity);
        _unitOfWork.Save();

    }

}