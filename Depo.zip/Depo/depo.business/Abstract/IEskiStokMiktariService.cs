using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IEskiStokMiktariService
{
    Task<EskiStokMiktari> GetById(int id);
    Task<List<EskiStokMiktari>> GetAll();
    void Create(EskiStokMiktari entity);
    void Update(EskiStokMiktari entity);
    void Delete(EskiStokMiktari entity);
    Task<List<EskiStokMiktari>> GetAktif();
    Task<List<EskiStokMiktari>> GetsStokMiktariByStokId(int? stokId);

}