using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IDepoService
{
    Task<Depo> GetById(int id);
    Task<List<Depo>> GetAll();
    void Create(Depo entity);
    void Update(Depo entity);
    void Delete(Depo entity);
    Task<List<Depo>> GetAktif();
    Task UpdateGetWithTedarikci(Depo entity,List<int> tedarikci);
    Task<Depo> GetDepoWithTedarikci(int id);
    Task<Depo> GetFilterPersonel(int id);
}