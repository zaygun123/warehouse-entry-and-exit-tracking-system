using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IEnvanterService
{
    Task<Envanter> GetById(int id);
    Task<List<Envanter>> GetAll();
    void Create(Envanter entity);
    void Update(Envanter entity);
    void Delete(Envanter entity);
    Task<List<Envanter>> GetAktif();
    Task<List<Envanter>> GetFilterUrun(int? id);

}