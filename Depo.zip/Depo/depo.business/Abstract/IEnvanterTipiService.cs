using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IEnvanterTipiService
{
    Task<EnvanterTipi> GetById(int id);
    Task<List<EnvanterTipi>> GetAll();
    void Create(EnvanterTipi entity);
    void Update(EnvanterTipi entity);
    void Delete(EnvanterTipi entity);
    Task<List<EnvanterTipi>> GetAktif();
}