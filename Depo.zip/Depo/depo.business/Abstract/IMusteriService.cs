using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IMusteriService
{
    Task<Musteri> GetById(int id);
    Task<List<Musteri>> GetAll();
    void Create(Musteri entity);
    void Update(Musteri entity);
    void Delete(Musteri entity);
    Task<List<Musteri>> GetAktif();
    Task<Musteri> GetFilterSiparis(int id);
    
}