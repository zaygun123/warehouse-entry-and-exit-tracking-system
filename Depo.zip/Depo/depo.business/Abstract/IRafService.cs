using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IRafService
{
    Task<Raf> GetById(int id);
    Task<List<Raf>> GetAll();
    void Create(Raf entity);
    void Update(Raf entity);
    void Delete(Raf entity);
    Task<List<Raf>> GetAktif();
    Task<List<Raf>> GetRafsByDepoId(int? id);
    Task<Raf> GetFilterStok(int id);
    
}