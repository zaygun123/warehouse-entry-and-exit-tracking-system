using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IStokHareketleriService
{
    Task<StokHareketleri> GetById(int id);
    Task<List<StokHareketleri>> GetAll();
    void Create(StokHareketleri entity);
    void Update(StokHareketleri entity);
    void Delete(StokHareketleri entity);
    Task<List<StokHareketleri>> GetAktif();
    Task<List<StokHareketleri>> GetStokHareketisByStokId(int ? id);
    Task<List<StokHareketleri>> GetStokHareketlerisByPersonelId(int? id);


}