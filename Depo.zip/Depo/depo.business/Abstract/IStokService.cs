using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IStokService
{
    Task<Stok> GetById(int id);
    Task<List<Stok>> GetAll();
    void Create(Stok entity);
    void Update(Stok entity);
    void Delete(Stok entity);
    Task<List<Stok>> GetAktif();
    Task<List<Stok>> GetFilterSiparis(int? id);
    Task<List<Stok>> GetStoksByRafId(int? id);
}