using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IKategoriService
{
    Task<Kategori> GetById(int id);
    Task<List<Kategori>> GetAll();
    void Create(Kategori entity);
    void Update(Kategori entity);
    void Delete(Kategori entity);
    Task<List<Kategori>> GetAktif();
    Task<Kategori> GetFilterUrun(int id);
    
}