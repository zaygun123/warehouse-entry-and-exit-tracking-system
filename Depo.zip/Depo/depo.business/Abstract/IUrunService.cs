using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IUrunService
{
    Task<Urun> GetById(int id);
    Task<List<Urun>> GetAll();
    void Create(Urun entity);
    void Update(Urun entity);
    void Delete(Urun entity);
    Task<List<Urun>> GetAktif();
    Task UpdateGetWithEnvanter(Urun entity,List<int> envanter);
    Task<Urun> GetUrunWithEnvanter(int id);

}