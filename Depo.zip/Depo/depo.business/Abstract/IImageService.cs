using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IImageService
{
    Task<Image> GetById(int id);
    Task<List<Image>> GetAll();
    void Create(Image entity);
    void Update(Image entity);
    void Delete(Image entity);
    Task<List<Image>> GetAktif();
    Task<List<Image>> GetFilterUrun(int? id);
    
}