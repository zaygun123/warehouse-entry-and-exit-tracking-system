using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface ISevkiyatService
{
    Task<Sevkiyat> GetById(int id);
    Task<List<Sevkiyat>> GetAll();
    void Create(Sevkiyat entity);
    void Update(Sevkiyat entity);
    void Delete(Sevkiyat entity);
    Task<List<Sevkiyat>> GetAktif();
    Task<Sevkiyat> GetFilterSiparis(int id);
}