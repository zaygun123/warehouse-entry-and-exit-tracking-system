using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IPersonelService
{
    Task<Personel> GetById(int id);
    Task<List<Personel>> GetAll();
    void Create(Personel entity);
    void Update(Personel entity);
    void Delete(Personel entity);
    Task<List<Personel>> GetAktif();
    Task<Personel> GetFilterStokHareketleri(int id);
}