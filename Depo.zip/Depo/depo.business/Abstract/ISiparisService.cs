using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface ISiparisService
{
    Task<Siparis> GetById(int id);
    Task<List<Siparis>> GetAll();
    void Create(Siparis entity);
    void Update(Siparis entity);
    void Delete(Siparis entity);
    Task<List<Siparis>> GetAktif();
    Task UpdateGetWithStok(Siparis entity,List<int> stok);
    Task<List<Siparis>> GetFilterSevkiyat(int? id);
    Task<Siparis> GetSiparisWithStok(int id);
}