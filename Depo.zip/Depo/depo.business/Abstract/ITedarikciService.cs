using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface ITedarikciService
{
    Task<Tedarikci> GetById(int id);
    Task<List<Tedarikci>> GetAll();
    void Create(Tedarikci entity);
    void Update(Tedarikci entity);
    void Delete(Tedarikci entity);
    Task<List<Tedarikci>> GetAktif();
    Task<List<Tedarikci>> GetFilterDepo(int? id);

}