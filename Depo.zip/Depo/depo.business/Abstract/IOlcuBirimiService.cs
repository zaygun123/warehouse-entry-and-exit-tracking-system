using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.business.Abstract;
public interface IOlcuBirimiService
{
    Task<OlcuBirimi> GetById(int id);
    Task<List<OlcuBirimi>> GetAll();
    void Create(OlcuBirimi entity);
    void Update(OlcuBirimi entity);
    void Delete(OlcuBirimi entity);
    Task<List<OlcuBirimi>> GetAktif();
}