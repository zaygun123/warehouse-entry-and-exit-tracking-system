using AutoMapper;
using depo.entity;
using depo.webui.Models;
using depo.webui.Models.ViewModel;

namespace depo.webui.Mapping;
public class MapProfile :Profile
{
    public MapProfile()
    {
        CreateMap<Depo,DepoViewModel>().ReverseMap();
        CreateMap<EnvanterTipi,EnvanterTipiViewModel>().ReverseMap();
        CreateMap<Envanter,EnvanterViewModel>().ReverseMap();
        CreateMap<Image,ImageViewModel>().ReverseMap();
        CreateMap<Kategori,KategoriViewModel>().ReverseMap();
        CreateMap<Musteri,MusteriViewModel>().ReverseMap();
        CreateMap<OlcuBirimi,OlcuBirimiViewModel>().ReverseMap();
        CreateMap<Personel,PersonelViewModel>().ReverseMap();
        CreateMap<Sevkiyat,SevkiyatViewModel>().ReverseMap();
        CreateMap<Siparis,SiparisViewModel>().ReverseMap();
        CreateMap<StokHareketleri,StokHareketleriViewModel>().ReverseMap();
        CreateMap<Stok,StokViewModel>().ReverseMap();
        CreateMap<Tedarikci,TedarikciViewModel>().ReverseMap();
        CreateMap<Urun,UrunViewModel>().ReverseMap();
        CreateMap<Raf,RafViewModel>().ReverseMap();
        CreateMap<EskiStokMiktari,EskiStokMiktariViewModel>().ReverseMap();


        CreateMap<Depo,DepoViewModel>();
        CreateMap<EnvanterTipi,EnvanterTipiViewModel>();
        CreateMap<Envanter,EnvanterViewModel>();
        CreateMap<Image,ImageViewModel>();
        CreateMap<Kategori,KategoriViewModel>();
        CreateMap<Musteri,MusteriViewModel>();
        CreateMap<OlcuBirimi,OlcuBirimiViewModel>();
        CreateMap<Personel,PersonelViewModel>();
        CreateMap<Sevkiyat,SevkiyatViewModel>();
        CreateMap<Siparis,SiparisViewModel>();
        CreateMap<StokHareketleri,StokHareketleriViewModel>();
        CreateMap<Stok,StokViewModel>();
        CreateMap<Tedarikci,TedarikciViewModel>();
        CreateMap<Urun,UrunViewModel>();
        CreateMap<Raf,RafViewModel>();
        CreateMap<EskiStokMiktari,EskiStokMiktariViewModel>();

    }
}