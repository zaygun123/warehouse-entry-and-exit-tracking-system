using Microsoft.AspNetCore.Identity;

namespace depo.webui.Identity;
public class User:IdentityUser
{
    public string? AdSoyad { get; set; }
}