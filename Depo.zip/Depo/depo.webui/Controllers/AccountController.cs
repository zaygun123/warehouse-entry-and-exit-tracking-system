using depo.webui.Identity;
using depo.webui.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace depo.webui.Controllers;
public class AccountController:Controller
{
    private UserManager<User> _userManager;
    private SignInManager<User> _signInManager;
    public AccountController(UserManager<User> userManager,SignInManager<User> signInManager)
    {
        _userManager=userManager;
        _signInManager=signInManager;
    }
    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        var user=await _userManager.FindByEmailAsync(model.Email);
        if(user==null)
        {
            model.Error="Kullanıcı adı veya şifre hatalıdır";
        }
        var result=await _signInManager.PasswordSignInAsync(user,model.Password,false,false); //ilk false uygulama kapatıldığında çıkış yapmasını engeller,diğeri ise şifre denemelerinde kilitlenmeyi önler.
        if(result.Succeeded)
        {
            return RedirectToAction("Depolar","Depo");
        }
        model.Error="Kullanıcı adı veya şifre hatalıdır";
        return View();
    }
    public IActionResult Register()
    {
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        var user=new User()
        {
            AdSoyad=model.NameSurname,
            UserName=model.UserName,
            Email=model.Email
        };
        var result=await _userManager.CreateAsync(user,model.Password);
        if(result.Succeeded)
        {
            model.Error="Kaydınız oluşturuldu.";
        }
        else
        {
            model.Error="Kaydınız oluşturulmadı.Tekrar deneyin";
        }
        return View(model);
    }
}