﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using depo.webui.Models;

namespace depo.webui.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
     // public async Task<IActionResult> SevkiyatSiparisEkle(int? id)
    // {           
    //     var model=new SiparisViewModel(){
    //         Siparises=await _siparisService.GetAktif(),
    //         SevkiyatId = id,
    //     };

    //     return View(model);
    // }

    // [HttpPost]
    // public async Task<IActionResult> SevkiyatSiparisEkle(SevkiyatViewModel model,List<int> siparis)
    // {
    //     var entity=_mapper.Map<Sevkiyat>(model);
    //     entity.Id=(int)model.EditId;
    //     model.SiparisIdList=new List<int>();
    //         foreach(var siparisId in siparis)
    //         {
    //             entity.Siparises.Add(new Siparis
    //             {
    //                 SevkiyatId=entity.Id,
    //             });
    //             model.SiparisIdList.Add(siparisId);
    //         }
    //     _sevkiyatService.Update(entity);
    //     return RedirectToAction("Sevkiyatlar");
    // }

}
