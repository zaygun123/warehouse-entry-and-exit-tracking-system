using System.Diagnostics.Eventing.Reader;
using AutoMapper;
using depo.business.Abstract;
using depo.entity;
using depo.webui.Models.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace depo.webui.Controllers;
public class DepoController:Controller
{
    private IDepoService _depoService;
    private IEnvanterService _envanterService;
    private IEnvanterTipiService _envantertipiService;
    private IImageService _imageService;
    private IKategoriService _kategoriService;
    private IMusteriService _musteriService;
    private IOlcuBirimiService _olcubirimiService;
    private IPersonelService _personelService;
    private ISevkiyatService _sevkiyatService;
    private ISiparisService _siparisService;
    private IStokHareketleriService _stokhareketleriService;
    private IStokService _stokService;
    private ITedarikciService _tedarikciService;
    private IUrunService _urunService;
    private IRafService _rafService;
    private IEskiStokMiktariService _eskiStokMiktariService;
    private IMapper _mapper;
    public DepoController(IDepoService depoService,IEnvanterService envanterService,IEnvanterTipiService envantertipiService,IImageService imageService,IKategoriService kategoriService,IMusteriService musteriService,IOlcuBirimiService olcuBirimiService,IPersonelService personelService,ISevkiyatService sevkiyatService,ISiparisService siparisService,IStokHareketleriService stokHareketleriService,IStokService stokService,ITedarikciService tedarikciService,IUrunService urunService,IRafService rafService,IEskiStokMiktariService eskiStokMiktariService,IMapper mapper)
    {
        _depoService=depoService;
        _envanterService=envanterService;
        _envantertipiService=envantertipiService;
        _imageService=imageService;
        _kategoriService=kategoriService;
        _musteriService=musteriService;
        _olcubirimiService=olcuBirimiService;
        _personelService=personelService;
        _sevkiyatService=sevkiyatService;
        _siparisService=siparisService;
        _stokhareketleriService=stokHareketleriService;
        _stokService=stokService;
        _tedarikciService=tedarikciService;
        _urunService=urunService;
        _rafService=rafService;
        _eskiStokMiktariService=eskiStokMiktariService;
        _mapper=mapper;
    }
    public async Task<IActionResult> DepoEkle(int? id)
    {
        var model=new DepoViewModel()
        {
            Rafs=await _rafService.GetAktif(),
        };
        if(id!=null)
        {
            var entity=await _depoService.GetById(id??1);
            model=_mapper.Map<DepoViewModel>(entity);
            model.EditId=entity.Id;
            model.Depos=await _depoService.GetAktif();
            model.Tedarikcis = await _tedarikciService.GetAktif();
            model.Rafs=await _rafService.GetAktif();
            model.TedarikciIdList = new List<int>();
            foreach (var item in entity.DepoTedarikcis)
            {
                if (item != null && item.TedarikciId != null)
                {
                    model.TedarikciIdList.Add(item.TedarikciId);
                }
            }
        }
        model.Tedarikcis = await _tedarikciService.GetAktif();
        return View(model);
    }
        [HttpPost]
        public  async Task<IActionResult> DepoEkle(DepoViewModel model)
        {
            var entity=_mapper.Map<Depo>(model);
            if (model.EditId == null)
            {
                _depoService.Create(entity);

                if(model.TedarikciIdList !=null)
                {
                    await _depoService.UpdateGetWithTedarikci(entity,model.TedarikciIdList);
                }
            }
            else
            {
                entity.Id=(int)model.EditId;
                 _depoService.Update(entity);

                if(model.TedarikciIdList !=null)
                {
                    await _depoService.UpdateGetWithTedarikci(entity,model.TedarikciIdList);
                }
            }
            return RedirectToAction("Depolar");
        }
        
    public async Task<IActionResult> DepoDelete(int id)
    {
        var entity=await _depoService.GetById((int) id);
        entity.Passive=true;
        _depoService.Update(entity);
        return RedirectToAction("Depolar");
    }

    public async Task<IActionResult> Depolar()
    {
        var model = new DepoViewModel(){
            Depos = await _depoService.GetAktif(),
        };

        return View(model);
    }
    public async Task<IActionResult> DepoDetay(int id)
    {
        var model = new DepoViewModel();
        var entity = await _depoService.GetById(id);
        model = _mapper.Map<DepoViewModel>(entity);
        model.Tedarikcis = await _tedarikciService.GetFilterDepo(id);
        model.Rafs=await _rafService.GetRafsByDepoId(id);
        return View(model);
    }
    public async Task<IActionResult> PersonelEkle(int? id)
    {
        var model=new PersonelViewModel(){
         Depos=await _depoService.GetAktif(),
         StokHareketleris=await _stokhareketleriService.GetAktif()
        };
        if(id!=null)
        {
            var entity=await _personelService.GetById(id??1);
            model=_mapper.Map<PersonelViewModel>(entity);
            model.EditId=(int)id;
            model.Depos=await _depoService.GetAktif();
            model.StokHareketleris=await _stokhareketleriService.GetAktif();
        }
        return View(model);
    }
    [HttpPost]
    public  IActionResult PersonelEkle(PersonelViewModel model)
    {
        var entity=_mapper.Map<Personel>(model);
        if (model.EditId == null)
        {
        _personelService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _personelService.Update(entity);
        }
        return RedirectToAction("Personeller");
    }

    public async Task<IActionResult> PersonelDelete(int id)
    {
        var entity=await _personelService.GetById((int) id);
        entity.Passive = true;
        _personelService.Update(entity);
        return RedirectToAction("Personeller");
    }
    public async Task<IActionResult> Personeller()
    {
        var model = new PersonelViewModel(){
            Personels = await _personelService.GetAktif()
        };
        return View(model);
    }
    public async Task<IActionResult> PersonelDetay(int id)
    {
        var model = new PersonelViewModel();
        var entity = await _personelService.GetById((int) id);
        model = _mapper.Map<PersonelViewModel>(entity);
        model.StokHareketleris=await _stokhareketleriService.GetStokHareketlerisByPersonelId(id);
        return View(model);

    }
    public async Task<IActionResult> RafEkle(int? id)
    {
        var model=new RafViewModel(){
            Depos = await _depoService.GetAktif(),
            Stoks=await _stokService.GetAktif(),
        };
        if( id != null)
        {
            var entity=await _rafService.GetById(id??1);
            model=_mapper.Map<RafViewModel>(entity);
            model.EditId = (int)id;
            model.Depos = await _depoService.GetAktif();
            model.Stoks=await _stokService.GetAktif();

        }
        return View(model);
    }
    [HttpPost]
    public IActionResult RafEkle(RafViewModel model)
    {
        var entity=_mapper.Map<Raf>(model);
         if (model.EditId == null)
        {
        _rafService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _rafService.Update(entity);
        }
        return RedirectToAction("Raflar");
    }

    public async Task<IActionResult> RafDelete(int id)
    {
        var entity=await _rafService.GetById((int) id);
        entity.Passive = true;
        _rafService.Update(entity);
        return RedirectToAction("Raflar");
    }
    public async Task<IActionResult> Raflar()
    {
        var model = new RafViewModel(){
            Rafs= await _rafService.GetAktif(),
            Depos=await _depoService.GetAktif()
        };
        return View(model);
    }
    public async Task<IActionResult> RafDetay(int id)
    {
        var model = new RafViewModel();
        var entity = await _rafService.GetById((int) id);
        model = _mapper.Map<RafViewModel>(entity);
        model.Stoks=await _stokService.GetStoksByRafId(id);
        return View(model);    
    }
    public async Task<IActionResult> MusteriEkle(int id)
    {
        var model=new MusteriViewModel();
        var entity=await _musteriService.GetById((int) id);
        model=_mapper.Map<MusteriViewModel>(entity);
        return View(model);
    }
    [HttpPost]
    public  IActionResult MusteriEkle(MusteriViewModel model)
    {
        var entity=_mapper.Map<Musteri>(model);
        if (model.EditId == null)
        {
        _musteriService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _musteriService.Update(entity);
        }
        return RedirectToAction("Musteriler");
    }

    public async Task<IActionResult> MusteriDelete(int id)
    {
        var entity=await _musteriService.GetById((int) id);
        entity.Passive = true;
        _musteriService.Update(entity);
        return RedirectToAction("Musteriler");
    }
    public async Task<IActionResult> Musteriler()
    {
        var model = new MusteriViewModel(){
            Musteris = await _musteriService.GetAktif()
        };
        return View(model);
    }
    public async Task<IActionResult> TedarikciEkle(int? id)
    {
        var model=new TedarikciViewModel(){
            Depos=await _depoService.GetAktif(),
        };
        if( id != null)
        {
            var entity=await _tedarikciService.GetById(id??1);
            model=_mapper.Map<TedarikciViewModel>(entity);
            model.EditId = entity.Id;
            model.Depos=await _depoService.GetAktif();
            model.Tedarikcis=await _tedarikciService.GetAktif();
        }
        return View(model);
    }

    [HttpPost]
    public  IActionResult TedarikciEkle(TedarikciViewModel model)
    {
        var entity=_mapper.Map<Tedarikci>(model);
        if (model.EditId == null)
        {
        _tedarikciService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _tedarikciService.Update(entity);
        }
        return RedirectToAction("Tedarikciler");
    }
    public async Task<IActionResult> TedarikciDelete(int id)
    {
        var entity=await _tedarikciService.GetById((int) id);
        entity.Passive = true;
        _tedarikciService.Update(entity);
        return RedirectToAction("Tedarikciler");
    }
    public async Task<IActionResult> Tedarikciler()
    {
        var model = new TedarikciViewModel(){
            Tedarikcis = await _tedarikciService.GetAktif()
        };
        return View(model);
    }
    public async Task<IActionResult> SevkiyatEkle(int? id)
    {
        var model=new SevkiyatViewModel(){
            Siparises = await _siparisService.GetAktif(),
        };
        if( id != null)
        {
            var entity=await _sevkiyatService.GetById(id??1);
            model=_mapper.Map<SevkiyatViewModel>(entity);
            model.EditId = entity.Id;
            model.Siparises = await _siparisService.GetAktif();
        }
        return View(model);
    }
    [HttpPost]
    public  async Task<IActionResult> SevkiyatEkle(SevkiyatViewModel model)
    {
        var entity=_mapper.Map<Sevkiyat>(model);
        entity.Tarih=DateTime.Now;
        if (model.EditId == null)
        {
        _sevkiyatService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _sevkiyatService.Update(entity);
        }
        return RedirectToAction("Sevkiyatlar");
    }
    public async Task<IActionResult> SevkiyatDelete(int id)
    {
        var entity=await _sevkiyatService.GetById((int) id);
        entity.Passive = true;
        _sevkiyatService.Update(entity);
        return RedirectToAction("Sevkiyatlar");
    }
    public async Task<IActionResult> Sevkiyatlar()
    {
        var model = new SevkiyatViewModel(){
            Sevkiyats = await _sevkiyatService.GetAktif()
        };
        return View(model);
    }
    public async Task<IActionResult> SevkiyatDetay(int Id)
    {
        var model=new SevkiyatViewModel();
        var entity=await _sevkiyatService.GetById((int) Id);
        model=_mapper.Map<SevkiyatViewModel>(entity);
        model.Siparises=await _siparisService.GetFilterSevkiyat(Id);
        return View(model);
    }

    public async Task<IActionResult> SiparisEkle(int? id,int stokId)
    {
        var model=new SiparisViewModel(){
            Musteris=await _musteriService.GetAktif(),
            Stoks=await _stokService.GetAktif(),
            Sevkiyats=await _sevkiyatService.GetAktif()
        };
        if( id != null)
        {
            var entity=await _siparisService.GetById(id??1);
            model=_mapper.Map<SiparisViewModel>(entity);
            model.EditId =entity.Id;
            model.Musteris=await _musteriService.GetAktif();
            model.Stoks=await _stokService.GetAktif();
            model.Sevkiyats=await _sevkiyatService.GetAktif();
            model.AdetList=new List<int>();
            model.StokIdList= new List<int>();
            foreach (var item in entity.SiparisStoks)
            {
              if (item != null && item.StokId != null)
                {
                    model.StokIdList.Add(item.StokId);
                }
            }
            // foreach(var item in model.Stoks)
            // {
            //     if(item != null && item.Id !=null)
            //     {
            //         model.AdetList.Add(item.Id);
            //     }
            // }
        }
        return View(model);
    }
    [HttpPost]
    public  async Task<IActionResult> SiparisEkle(SiparisViewModel model)
    {
        var entity=_mapper.Map<Siparis>(model);
        entity.Tarih=DateTime.Now;
        if (model.EditId == null) 
        {
            _siparisService.Create(entity);
            if(model.StokIdList !=null)
            {
                 await _siparisService.UpdateGetWithStok(entity,model.StokIdList);
            }
        }
        else
        {
            entity.Id=model.EditId;
            _siparisService.Update(entity);
            if(model.StokIdList !=null)
            {
                await _siparisService.UpdateGetWithStok(entity,model.StokIdList);
            }
        }           
         entity.SiparisAgirligi=0;
        //  int index=0;
        // foreach(var item in model.StokIdList)
        // {  
        //     var entity2=await  _urunService.GetById(item);
        //     if(entity2!=null)
        //     {
        //         entity.Adet=model.AdetList[index];
        //         entity.SiparisAgirligi+=(entity.Adet*entity2.Agirlik)/1000; 
        //     }
        //     index ++;
        // }          
        for (int index = 0; index < model.StokIdList.Count; index++)
        {
            var stokId = model.StokIdList[index];
            var entity2 = await _urunService.GetById(stokId);
            if (entity2 != null)
            {
                entity.Adet = model.AdetList[index];
                entity.SiparisAgirligi += (entity.Adet * entity2.Agirlik) / 1000;
            }
        }
    
        _siparisService.Update(entity);
        return RedirectToAction("Siparisler");
    }
    public async Task<IActionResult> SiparisDelete(int id)
    {
        var entity=await _siparisService.GetById((int) id);
        entity.Passive=true;
        _siparisService.Update(entity);
        return RedirectToAction("Siparisler");
    }
    public async Task<IActionResult> Siparisler()
    {
        var model = new SiparisViewModel(){
            Siparises = await _siparisService.GetAktif(),
        };

        return View(model);
    }
    public async Task<IActionResult> SiparisDetay(int id)
    {
        var model = new SiparisViewModel();
        var entity = await _siparisService.GetById((int) id);
        model = _mapper.Map<SiparisViewModel>(entity);
        model.Stoks = await _stokService.GetFilterSiparis(id);
        return View(model);
    }
    public async Task<IActionResult> UrunEkle(int? id)
    {
        var model=new UrunViewModel(){
            Images=await _imageService.GetAktif(),
            Kategoris=await _kategoriService.GetAktif(),
            OlcuBirimis=await _olcubirimiService.GetAktif(),
            Envanters=await _envanterService.GetAktif(),
            Uruns=await _urunService.GetAktif()  
        };
        if( id != null)
        {
            var entity=await _urunService.GetById(id??1);
            model=_mapper.Map<UrunViewModel>(entity);
            model.EditId = entity.Id;
            model.Images = await _imageService.GetAktif();
            model.Uruns=await _urunService.GetAktif();
            model.Kategoris=await _kategoriService.GetAktif();
            model.OlcuBirimis=await _olcubirimiService.GetAktif();
            model.Envanters=await _envanterService.GetAktif();
            model.EnvanterIdList= new List<int>();
            foreach(var item in entity.EnvanterUruns)
            {
                if(item!=null && item.EnvanterId !=null)
                {
                    model.EnvanterIdList.Add(item.EnvanterId);
                }
            }
        }
        return View(model);
    }
    [HttpPost]
    public async Task<IActionResult> UrunEkle(UrunViewModel model)
    {
        var entity=_mapper.Map<Urun>(model);
        entity.Tarih=DateTime.Now;
         if (model.EditId == null)
        {
            _urunService.Create(entity);

            if(model.EnvanterIdList !=null)
            {
                await _urunService.UpdateGetWithEnvanter(entity,model.EnvanterIdList);
            }
        }
        else
        {
            entity.Id=(int)model.EditId;
            _urunService.Update(entity);
            if(model.EnvanterIdList !=null)
            {
            await _urunService.UpdateGetWithEnvanter(entity,model.EnvanterIdList);
            }
        }
        return RedirectToAction("Urunler");
    }
    public async Task<IActionResult> UrunDelete(int id)
    {
        var entity=await _urunService.GetById((int) id);
        entity.Passive = true;
        _urunService.Update(entity);
        return RedirectToAction("Urunler");
    }
    public async Task<IActionResult> UrunDetay(int id)
    {
        var model = new UrunViewModel();
        var entity = await _urunService.GetById((int) id);
        model = _mapper.Map<UrunViewModel>(entity);
        model.Envanters = await _envanterService.GetFilterUrun(id);
        return View(model);
    }
    public async Task<IActionResult> Urunler()
    {
        var model = new UrunViewModel(){
            Uruns= await _urunService.GetAktif()
        };
        return View(model);
    }

    public async Task<IActionResult> ResimEkle(int? id)
    {
        var model=new ImageViewModel(){
            UrunId = id,
            Images = await _imageService.GetFilterUrun(id??1),
        };

        return View(model);
    }
    [HttpPost]
    public IActionResult ResimEkle(ImageViewModel model)
    {
        var entity=_mapper.Map<Image>(model);
         if (model.EditId == null)
        {
        _imageService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _imageService.Update(entity);
        }
        return RedirectToAction("Urunler");
    }

    public async Task<IActionResult> ResimDelete(int id)
    {
        var entity=await _imageService.GetById((int) id);
        entity.Passive = true;
        _imageService.Update(entity);
        return RedirectToAction("Urunler");
    }
    public async Task<IActionResult> Resimler()
    {
        var model = new ImageViewModel(){
            Images= await _imageService.GetAktif(),
        };
        return View(model);
    }

    public async Task<IActionResult> KategoriEkle(int? id)
    {
        var model=new KategoriViewModel();
        if(id!=null)
        {
        var entity=await _kategoriService.GetById( id??1);
        model=_mapper.Map<KategoriViewModel>(entity); 
        model.EditId = (int)id;
        }

        return View(model);
    }
    [HttpPost]
    public IActionResult KategoriEkle(KategoriViewModel model)
    {
        var entity=_mapper.Map<Kategori>(model);
         if (model.EditId == null)
        {
        _kategoriService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _kategoriService.Update(entity);
        }
        return RedirectToAction("Kategoriler");
    }

    public async Task<IActionResult> KategoriDelete(int id)
    {
        var entity=await _kategoriService.GetById((int) id);
        entity.Passive = true;
        _kategoriService.Update(entity);
        return RedirectToAction("Kategoriler");
    }
    public async Task<IActionResult> Kategoriler()
    {
        var model = new KategoriViewModel(){
            Kategoris= await _kategoriService.GetAktif(),
        };
        return View(model);
    }
    public async Task<IActionResult> OlcuBirimiEkle(int? id)
    {
        var model=new OlcuBirimiViewModel();

        if(id != null)
        {
            var entity=await _olcubirimiService.GetById(id??1);
            model=_mapper.Map<OlcuBirimiViewModel>(entity);
            model.EditId = (int)id;
        }
        return View(model);
    }
    [HttpPost]
    public IActionResult OlcuBirimiEkle(OlcuBirimiViewModel model)
    {
        var entity=_mapper.Map<OlcuBirimi>(model);
         if (model.EditId == null)
        {
        _olcubirimiService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _olcubirimiService.Update(entity);
        }
        return RedirectToAction("Olcubirimleri");
    }

    public async Task<IActionResult> OlcuBirimiDelete(int id)
    {
        var entity=await _olcubirimiService.GetById((int) id);
        entity.Passive = true;
        _olcubirimiService.Update(entity);
        return RedirectToAction("Olcubirimleri");
    }
    public async Task<IActionResult> Olcubirimleri()
    {
        var model = new OlcuBirimiViewModel(){
            OlcuBirimis= await _olcubirimiService.GetAktif(),
        };
        return View(model);
    }
    public async Task<IActionResult> StokEkle(int? id)
    {
        var model=new StokViewModel()
        {
            Uruns=await _urunService.GetAktif(),
            Depos=await _depoService.GetAktif(),
            Rafs=await _rafService.GetAktif(),
            StokHareketleris=await _stokhareketleriService.GetAktif(),
            EskiStokMiktaris=await _eskiStokMiktariService.GetAktif(),
            
        };
        if( id != null)
        {
            var entity=await _stokService.GetById(id??1);
            model=_mapper.Map<StokViewModel>(entity);
            model.EditId = (int)id;
            model.Stoks=await _stokService.GetAktif();
            model.Uruns = await _urunService.GetAktif();
            model.Depos=await _depoService.GetAktif();
            model.Rafs=await _rafService.GetAktif();
            model.StokHareketleris=await _stokhareketleriService.GetAktif();
            model.EskiStokMiktaris=await _eskiStokMiktariService.GetAktif();
        }
        return View(model);
    }
    [HttpPost]
    public async Task<IActionResult> StokEkle(StokViewModel model,int StokId)
    {
        var entity=_mapper.Map<Stok>(model);
         if (model.EditId == null)
        {
        _stokService.Create(entity);  
        }
        else
        {
            entity.Id=(int)model.EditId;
            _stokService.Update(entity);
        } 
        return RedirectToAction("Stoklar");
    }

    public async Task<IActionResult> StokDelete(int id)
    {
        var entity=await _stokService.GetById((int) id);
        entity.Passive = true;
        _stokService.Update(entity);
        return RedirectToAction("Stoklar");
    }
    public async Task<IActionResult> Stoklar()
    {
        var model = new StokViewModel(){
            Stoks= await _stokService.GetAktif(),
        };
        return View(model);
    }
    public async Task<IActionResult> StokDetay(int id)
    {
        var model = new StokViewModel();
        var entity = await _stokService.GetById((int) id);
        model = _mapper.Map<StokViewModel>(entity);
        return View(model);
    }
    public async Task<IActionResult> StokHareketleriEkle(int? id)
    {
        var model=new StokHareketleriViewModel(){
            Personels = await _personelService.GetAktif(),
            Stoks=await _stokService.GetAktif(),            
        };
        if( id != null)
        {
            var entity=await _stokhareketleriService.GetById(id??1);
            model=_mapper.Map<StokHareketleriViewModel>(entity);
            model.EditId = (int)id;
            model.Personels = await _personelService.GetAktif();
            model.Stoks=await _stokService.GetAktif();
        }
        return View(model);
    }
    [HttpPost]    
    public async Task<IActionResult> StokHareketleriEkle(StokHareketleriViewModel model, int StokId)
    {
    var entity = _mapper.Map<StokHareketleri>(model);
    entity.Tarih = DateTime.Now;
    if (model.EditId == null)
    {
        _stokhareketleriService.Create(entity);
    }
    else
    {
        entity.Id = (int)model.EditId;
        _stokhareketleriService.Update(entity);
    }    
    var stokMiktari = new EskiStokMiktari();

    var entity2 = await _stokService.GetById(StokId);
        stokMiktari.StokId = entity2.Id;
        stokMiktari.StokHareketleriId = entity.Id;
        stokMiktari.EskiStok = entity2.StokMiktari;
        _eskiStokMiktariService.Create(stokMiktari);

    if (entity.Durum == 0 && entity2.StokMiktari + entity.StokMiktari <= entity2.MaxStok)
    {
        entity2.StokMiktari += entity.StokMiktari;
    }
    else if (entity.Durum == 1 && entity2.StokMiktari - entity.StokMiktari >= entity2.MinStok)
    {
        entity2.StokMiktari -= entity.StokMiktari;
    }
    else
    {
        TempData["Error"] = "Stok miktarı ekleme/çıkarma şartlarını sağlamıyor! Minimum ve maksimum stok miktarına dikkat ediniz.";
    }

    var entity3=await  _urunService.GetById(StokId);
    if(entity3!=null)
    {   
        entity.ToplamAgirlik=(entity.StokMiktari*entity3.Agirlik)/1000;            
        _stokhareketleriService.Update(entity);                
    }

    return RedirectToAction("StokHareketleri");
    }
    public async Task<IActionResult> StokHareketleriDelete(int id)
    {
        var entity=await _stokhareketleriService.GetById((int) id);
        entity.Passive = true;
        _stokhareketleriService.Update(entity);
        return RedirectToAction("StokHareketleri");
    }
    public async Task<IActionResult> StokHareketleri()
    {
        var model = new StokHareketleriViewModel(){
            StokHareketleris= await _stokhareketleriService.GetAktif(),
        };
        return View(model);
    }
    public async Task<IActionResult> StokHareketleriDetay(int id)
    {
        var model = new StokHareketleriViewModel();
        var entity = await _stokhareketleriService.GetById(id);
        model = _mapper.Map<StokHareketleriViewModel>(entity);
        model.StokHareketleris=await _stokhareketleriService.GetStokHareketisByStokId(id);
        model.EskiStokMiktaris = await _eskiStokMiktariService.GetsStokMiktariByStokId(id);
        return View(model);
    }
    public async Task<IActionResult> StokHareketiIncele(int id)
    {
        var model = new StokViewModel()
        {
            EditId = id,
        };
        if(id!=null)
        {
            var entity = await _stokService.GetById(id);
            model = _mapper.Map<StokViewModel>(entity);
            model.EditId = entity.Id;
        }
        model.StokHareketleris=await _stokhareketleriService.GetStokHareketisByStokId(id);
        model.EskiStokMiktaris=await _eskiStokMiktariService.GetsStokMiktariByStokId(id);
        
        return View(model);
    }
    public async Task<IActionResult> EnvanterEkle(int? id)
    {
        var model=new EnvanterViewModel(){
            EnvanterTipis=await _envantertipiService.GetAktif()
        };
        if( id != null)
        {
            var entity=await _envanterService.GetById(id??1);
            model=_mapper.Map<EnvanterViewModel>(entity);
            model.EditId = (int)id;
            model.EnvanterTipis=await _envantertipiService.GetAktif();

        }
        return View(model);
    }
    
    [HttpPost]
    public IActionResult EnvanterEkle(EnvanterViewModel model)
    {
        var entity=_mapper.Map<Envanter>(model);
         if (model.EditId == null)
        {
        _envanterService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _envanterService.Update(entity);
        }
        return RedirectToAction("Envanterler");
    }
    public async Task<IActionResult> EnvanterDelete(int id)
    {
        var entity=await _envanterService.GetById((int) id);
        entity.Passive = true;
        _envanterService.Update(entity);
        return RedirectToAction("Envanterler");
    }
    public async Task<IActionResult> Envanterler()
    {
        var model = new EnvanterViewModel(){
            Envanters= await _envanterService.GetAktif(),
        };
        return View(model);
    }
    public async Task<IActionResult> EnvanterTipiEkle(int? id)
    {
        var model=new EnvanterTipiViewModel();

        var entity=await _envantertipiService.GetById(id??1);
        model=_mapper.Map<EnvanterTipiViewModel>(entity);
        return View(model);
    }
    
    [HttpPost]
    public IActionResult EnvanterTipiEkle(EnvanterTipiViewModel model)
    {
        var entity=_mapper.Map<EnvanterTipi>(model);
         if (model.EditId == null)
        {
        _envantertipiService.Create(entity);
        }
        else
        {
            entity.Id=(int)model.EditId;
            _envantertipiService.Update(entity);
        }
        return RedirectToAction("EnvanterTipleri");
    }
    public async Task<IActionResult> EnvanterTipiDelete(int id)
    {
        var entity=await _envantertipiService.GetById((int) id);
        entity.Passive = true;
        _envantertipiService.Update(entity);
        return RedirectToAction("EnvanterTipleri");
    }
    public async Task<IActionResult> EnvanterTipleri()
    {
        var model = new EnvanterTipiViewModel(){
            EnvanterTipis= await _envantertipiService.GetAktif(),
        };
        return View(model);
    }  
    public IActionResult Index()
    {
        return View();
    }


   
}