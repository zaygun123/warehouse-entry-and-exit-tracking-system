using depo.business.Abstract;
using depo.business.Concrete;
using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.webui.Identity;
using depo.webui.Mapping;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;


var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<IdentityContext>(options =>
{
   options.UseSqlServer(builder.Configuration.GetConnectionString("MssSqlConnection"));
});
builder.Services.AddDbContext<GeneralContext>(options =>
{
   options.UseSqlServer(builder.Configuration.GetConnectionString("MssSqlConnection"));
});

builder.Services.AddIdentity<User,IdentityRole>().AddEntityFrameworkStores<IdentityContext>().AddDefaultTokenProviders();
builder.Services.Configure<IdentityOptions>(options=>{
    options.Password.RequireDigit=true; //oluşturulacak şifrede mutlaka sayısal değer olmalıdır.
    options.Password.RequireLowercase=true; //küçük harf
    options.Password.RequireUppercase=true; //büyük harf
    options.Password.RequiredLength=6;

    options.User.RequireUniqueEmail=true; //unique email
    options.SignIn.RequireConfirmedEmail=false; //hesap oluşturulduktan sonra mutlaka email doğrulaması yapılmak için true
});
builder.Services.ConfigureApplicationCookie(options =>
{
    // Cookie settings
    options.Cookie.HttpOnly = true;
    options.ExpireTimeSpan = TimeSpan.FromMinutes(3000);
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.SlidingExpiration = true;
});


builder.Services.AddScoped<IUnitOfWork,UnitOfWork>();
builder.Services.AddScoped<IDepoService,DepoManager>();
builder.Services.AddScoped<IEnvanterService,EnvanterManager>();
builder.Services.AddScoped<IEnvanterTipiService,EnvanterTipiManager>();
builder.Services.AddScoped<IImageService,ImageManager>();
builder.Services.AddScoped<IKategoriService,KategoriManager>();
builder.Services.AddScoped<IMusteriService,MusteriManager>();
builder.Services.AddScoped<IOlcuBirimiService,OlcuBirimiManager>();
builder.Services.AddScoped<IPersonelService,PersonelManager>();
builder.Services.AddScoped<ISevkiyatService,SevkiyatManager>();
builder.Services.AddScoped<ISiparisService,SiparisManager>();
builder.Services.AddScoped<IStokHareketleriService,StokHareketleriManager>();
builder.Services.AddScoped<IStokService,StokManager>();
builder.Services.AddScoped<ITedarikciService,TedarikciManager>();
builder.Services.AddScoped<IUrunService,UrunManager>();
builder.Services.AddScoped<IRafService,RafManager>();
builder.Services.AddScoped<IEskiStokMiktariService,EskiStokMiktariManager>();

builder.Services.AddAutoMapper(typeof(MapProfile));
// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAuthentication();
app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Depo}/{action=Index}/{id?}");

app.Run();
