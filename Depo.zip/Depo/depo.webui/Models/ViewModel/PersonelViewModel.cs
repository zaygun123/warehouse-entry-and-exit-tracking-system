using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class PersonelViewModel:ViewModelBase
{
    public string? Ad { get; set; }
    public string? TelNo { get; set; }
    public string? Email { get; set; }
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public int? DepoId { get; set; }
    public Depo Depo {get; set;}
    public List<Depo> Depos { get; set; }
    public List<StokHareketleri> StokHareketleris { get; set; }
    public List<Personel> Personels { get; set; }
}