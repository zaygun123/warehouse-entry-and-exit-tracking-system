using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class EnvanterViewModel:ViewModelBase
{
    public string? Ad { get; set; }
    public List<Urun> Uruns { get; set; }
    public int? EnvantertipiId  { get; set; }
    public EnvanterTipi EnvanterTipi { get; set; }
    public List<EnvanterTipi> EnvanterTipis { get; set; }
    public List<Envanter> Envanters { get; set; }
}