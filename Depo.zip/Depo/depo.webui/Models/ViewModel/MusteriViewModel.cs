using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class MusteriViewModel:ViewModelBase
{    
    public string? MusteriNo { get; set; }
    public string? AdSoyad { get; set; }
    public string? TelNo { get; set; }
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public string? Email { get; set; }
    public List<Urun> Uruns { get; set; }
    public List<Siparis> Siparises { get; set; }    
    public List<Musteri> Musteris { get; set; }
}