using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class RafViewModel:ViewModelBase
{
    public string? RafNo { get; set; }
    public int?  DepoId { get; set; }
    public Depo Depo { get; set; }
    public List<Depo> Depos { get; set; }
    public int? StokId{ get; set; }
    public Stok Stok { get; set; }
    public List<Stok> Stoks {get; set;}
    public List<Raf> Rafs { get; set; }
}