using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class KategoriViewModel:ViewModelBase
{
    public string? kategoriadi { get; set; }
    public List<Urun> Uruns { get; set; }
    public List<Kategori> Kategoris { get; set; }
}