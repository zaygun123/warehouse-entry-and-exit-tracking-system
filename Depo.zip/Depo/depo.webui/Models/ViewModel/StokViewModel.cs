using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class StokViewModel:ViewModelBase
{
    public string? SKUno { get; set; }
    public double? StokMiktari { get; set; }
    public double? MinStok { get; set; }
    public double? MaxStok { get; set; }
    public double? KritikStokMiktari { get; set; }
    public int? UrunId { get; set; }
    public Urun Urun { get; set; }
    public List<Urun> Uruns { get; set; }
    public int? DepoId { get; set; }
    public Depo Depo { get; set; }
    public List<Depo> Depos { get; set; }
    public List<Stok> Stoks { get; set; }
    public List<Raf> Rafs { get; set; }
    public int? RafId { get; set; }
    public Raf Raf { get; set; }
    public List<Siparis> siparises { get; set; }
    public int? StokHareketleriId { get; set; }
    public StokHareketleri StokHareketleri { get; set; }
    public List<StokHareketleri> StokHareketleris { get; set; }
    public List<EskiStokMiktari> EskiStokMiktaris { get; set; }

     
}