using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class OlcuBirimiViewModel:ViewModelBase
{
    public string? olcubirimi { get; set; }
    public List<Urun> Uruns { get; set; }

    public List<OlcuBirimi> OlcuBirimis { get; set; }
}