namespace depo.webui.Models.ViewModel.Base;
public class ViewModelBase
{
    public int EditId { get; set; }
}