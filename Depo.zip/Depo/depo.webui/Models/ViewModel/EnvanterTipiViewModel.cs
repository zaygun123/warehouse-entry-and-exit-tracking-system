using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class EnvanterTipiViewModel:ViewModelBase
{
    public string? envantertipi { get; set; }
    public List<Envanter> Envanters { get; set; }
    public List<EnvanterTipi> EnvanterTipis { get; set; }
}