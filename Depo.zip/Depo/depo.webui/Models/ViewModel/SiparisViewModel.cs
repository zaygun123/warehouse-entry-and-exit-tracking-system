using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class SiparisViewModel:ViewModelBase
{
    public string? Adres { get; set; }
    public string? SiparisNo { get; set; }
    public double? SiparisAgirligi { get; set; }
    public double? Adet { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public DateTime Tarih { get; set; }
    public int? MusteriId { get; set; }
    public Musteri Musteri { get; set; }
    public List<Musteri> Musteris { get; set; }
    public int? SevkiyatId  { get; set; }
    public Sevkiyat Sevkiyat { get; set; }
    public List<Sevkiyat> Sevkiyats { get; set; }
    public List<Stok> Stoks { get; set; }
    public int? siparisDurumu { get; set; }
    public List<Siparis> Siparises { get; set; }
    public int? SiparisId { get; set; }
    public Siparis Siparis { get; set; }
    public List<int> StokIdList { get; set; }
    public List<int> AdetList { get; set; }


}