using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class StokHareketleriViewModel:ViewModelBase
{
    public double? StokMiktari { get; set; }
    public DateTime Tarih { get; set; }
    public double? ToplamAgirlik { get; set; }
    public int? PersonelId { get; set; }
    public Personel Personel { get; set; }
    public List<Personel> Personels { get; set; }
    public List<StokHareketleri> StokHareketleris { get; set; }
    public int? StokId { get; set; }
    public Stok Stok { get; set; }
    public List<Stok> Stoks { get; set; }
    public int? Durum { get; set; }
    public List<EskiStokMiktari> EskiStokMiktaris { get; set;}
    public int? EskiStokMiktariId { get; set; }
    public EskiStokMiktari EskiStokMiktari { get; set; }
}