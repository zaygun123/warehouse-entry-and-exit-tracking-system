using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models;
public class EskiStokMiktariViewModel:ViewModelBase
{
public double? EskiStok { get; set; }
public int? StokId { get; set; }
public Stok Stok { get; set; }
public List<Stok> Stoks { get; set; }
public List<EskiStokMiktari> EskiStokMiktaris { get; set; }
public int? StokHareketleriId { get; set; }
public StokHareketleri StokHareketleri { get; set; }
}