using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class ImageViewModel:ViewModelBase
{
    public string? image { get; set; }
    public int? UrunId { get; set; }
    public Urun Urun { get; set; }
    public List<Image> Images { get; set; }
}