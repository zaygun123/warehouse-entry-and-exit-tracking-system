using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class DepoViewModel:ViewModelBase
{ 
        public string? Depo_adi { get; set; }
        public string? Raf_no { get; set; }
        public double Doluluk_orani { get; set; }
        public List<Personel> Personels { get; set; }
        public List<Urun> Uruns { get; set; }
        public int? TedarikciId  { get; set; }
        public Tedarikci Tedarikci { get; set; }
        public List<Tedarikci> Tedarikcis { get; set; }
        public List<DepoTedarikci> DepoTedarikcis { get; set; }
        public List<Depo> Depos { get; set; }
        public List<Raf> Rafs { get; set; }
        public List<int> TedarikciIdList { get; set; }
        
}