using depo.entity;
using depo.webui.Models.ViewModel.Base;

namespace depo.webui.Models.ViewModel;
public class SevkiyatViewModel:ViewModelBase
{
    public string? SevkiyatNo { get; set; }
    public DateTime Tarih { get; set; }
    public int? SiparisId { get; set; }
    public Siparis Siparis { get; set; }
    public List<Siparis> Siparises { get; set; }
    public int? sevkiyatDurumu { get; set; }    
    public List<Sevkiyat> Sevkiyats { get; set; }
    public List<int> SiparisIdList { get; set; }

}