using depo.entity.Base;

namespace depo.entity;
public class Raf:EntityBase
{
    public string? RafNo { get; set; }
    public int?  DepoId { get; set; }
    public Depo Depo { get; set; }
    public List<Stok> Stoks {get; set;}
}