
using depo.entity.Base;

namespace depo.entity;
public class Depo:EntityBase
{
     public string? Depo_adi { get; set; }
     public double Doluluk_orani { get; set; }
     public List<Personel> Personels { get; set; }
     public List<Urun> Uruns { get; set; }
     public List<Raf> Rafs { get; set; }
     public List<DepoTedarikci> DepoTedarikcis { get; set; }
}