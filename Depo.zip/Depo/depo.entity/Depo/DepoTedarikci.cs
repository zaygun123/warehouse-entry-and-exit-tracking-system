
namespace depo.entity;
public class DepoTedarikci
{
    public int DepoId { get; set; }
    public Depo Depo { get; set; }
    public int TedarikciId { get; set; }
    public Tedarikci Tedarikci { get; set; }
}