using depo.entity.Base;

namespace depo.entity;
public class  Envanter:EntityBase
{
    public string? Ad { get; set; }
    public int? EnvanterTipiId { get; set; }
    public EnvanterTipi EnvanterTipi { get; set; }
    public List<EnvanterUrun> EnvanterUruns { get; set; }

}