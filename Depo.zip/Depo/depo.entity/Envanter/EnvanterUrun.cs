namespace depo.entity;
public class EnvanterUrun
{
    public int EnvanterId { get; set; }
    public Envanter Envanter { get; set; }
    public int UrunId { get; set; }
    public Urun Urun { get; set; }
}