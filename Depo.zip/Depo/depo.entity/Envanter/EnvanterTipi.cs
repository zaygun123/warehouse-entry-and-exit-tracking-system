using depo.entity.Base;

namespace depo.entity;
public class EnvanterTipi:EntityBase
{
    public string? envantertipi { get; set; }
    public List<Envanter> Envanters { get; set; }
}