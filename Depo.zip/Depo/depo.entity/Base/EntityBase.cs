namespace depo.entity.Base;
public class EntityBase
{
    public int Id { get; set; }
    public bool Passive { get; set; }
}