using depo.entity.Base;

namespace depo.entity;
public class Kategori:EntityBase
{

    public string? kategoriadi { get; set; }
    public List<Urun> Uruns { get; set; }
}