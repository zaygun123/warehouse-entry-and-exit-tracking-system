using depo.entity.Base;

namespace depo.entity;
public class Image:EntityBase
{

    public string? image { get; set; }

    public int? UrunId { get; set; }
    public Urun Urun { get; set; }

}