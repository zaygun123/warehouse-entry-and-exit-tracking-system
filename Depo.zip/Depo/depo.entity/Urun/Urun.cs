
using depo.entity.Base;

namespace depo.entity;
public class Urun:EntityBase
{
   
    public string? Ad { get; set; }
    public string? Kod { get; set; }
    public string? Fiyat { get; set; }
    public double? Agirlik { get; set; }
    public string? En { get; set; }
    public string? Boy { get; set; }
    public string? Derinlik { get; set; }
    public string? Barkod { get; set; }
    public int? OlcuBirimiId { get; set; }
    public OlcuBirimi OlcuBirimi { get; set; }
    public int? KategoriId {get; set;}
    public Kategori Kategori {get;set;}
    public int? MusteriId { get; set; }
    public Musteri Musteri { get; set; }


    //Hatali urun
    public string? HataSebebi { get; set; }

    //Iade urun
    public string? IadeSebebi { get; set; }
    public DateTime Tarih { get; set; }

    public List<Stok> Stoks { get; set; }
    public List<Image> Images { get; set; }

    public int? SiparisId { get; set; }
    public Siparis Siparis { get; set; }
    public string? image { get; set; }
   
    public List<EnvanterUrun> EnvanterUruns { get; set; }


}