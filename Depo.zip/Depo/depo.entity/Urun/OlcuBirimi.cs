using depo.entity.Base;

namespace depo.entity;
public class OlcuBirimi:EntityBase
{

    public string? olcubirimi { get; set; }
    public List<Urun> Uruns { get; set; }
}