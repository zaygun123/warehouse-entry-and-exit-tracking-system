using depo.entity.Base;

namespace depo.entity;
public class EskiStokMiktari:EntityBase
{
    public double? EskiStok { get; set; }
    public int? StokId { get; set; }
    public Stok Stok { get; set; }
    public int? StokHareketleriId { get; set; }
    public StokHareketleri StokHareketleri { get; set; }
}