using depo.entity.Base;

namespace depo.entity;
public class Stok:EntityBase
{
    public string? SKUno { get; set; }
    public double? StokMiktari { get; set; }
    public double? MinStok { get; set; }
    public double? MaxStok { get; set; }
    public double? KritikStokMiktari { get; set; }

    public int? UrunId { get; set; }
    public Urun Urun { get; set; }

    public int? DepoId { get; set; }
    public Depo Depo { get; set; }

    public List<SiparisStok> SiparisStoks { get; set; }
    public int? RafId { get; set; }
    public Raf Raf { get; set; }
    public List<StokHareketleri> StokHareketleris { get; set; }
    public List<EskiStokMiktari> EskiStokMiktaris { get; set; }

}