using depo.entity.Base;

namespace depo.entity;
public class Siparis:EntityBase
{
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public string? SiparisNo { get; set; }
    public DateTime Tarih { get; set; }
    public double? SiparisAgirligi { get; set; }
    public double? Adet { get; set; }
    public int? MusteriId { get; set; }
    public Musteri Musteri { get; set; }
    public int? SevkiyatId  { get; set; }
    public Sevkiyat Sevkiyat { get; set; }
    public int? siparisDurumu { get; set; }
    public List<SiparisStok> SiparisStoks { get; set; }
}