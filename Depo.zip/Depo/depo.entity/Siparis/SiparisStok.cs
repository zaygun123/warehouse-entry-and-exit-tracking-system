namespace depo.entity;
public class SiparisStok
{
    public int SiparisId { get; set; }
    public Siparis Siparis { get; set; }
    public int StokId { get; set; }
    public Stok Stok { get; set; }
}