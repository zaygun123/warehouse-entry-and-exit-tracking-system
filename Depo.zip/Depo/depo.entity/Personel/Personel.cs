using depo.entity.Base;

namespace depo.entity;
public class Personel:EntityBase
{
    public string? Ad { get; set; }
    public string? TelNo { get; set; }
    public string? Email { get; set; }
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public int? DepoId { get; set; }
    public Depo Depo {get; set;}
    public List<StokHareketleri> StokHareketleris { get; set; }
}