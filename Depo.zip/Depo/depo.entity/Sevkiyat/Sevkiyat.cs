using depo.entity.Base;

namespace depo.entity;
public class Sevkiyat:EntityBase
{
 
    public string? SevkiyatNo { get; set; }
    public DateTime Tarih { get; set; }
    public List<Siparis> Siparises { get; set; }
    public int? sevkiyatDurumu { get; set; }

}