using depo.entity.Base;

namespace depo.entity;
public class StokHareketleri:EntityBase
{
    
    public double? StokMiktari { get; set; }
    public DateTime Tarih { get; set; }
    public double? ToplamAgirlik { get; set; }
    public int? PersonelId { get; set; }
    public Personel Personel { get; set; }
    public int? StokId { get; set; }
    public Stok Stok { get; set; }
    public int? Durum { get; set; }
    public int? EskiStokMiktariId { get; set; }
    public EskiStokMiktari EskiStokMiktari { get; set; }
}