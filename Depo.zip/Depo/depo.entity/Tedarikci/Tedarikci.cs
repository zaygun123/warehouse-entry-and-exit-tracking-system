using depo.entity.Base;

namespace depo.entity;
public class Tedarikci:EntityBase
{
 
    public string? Ad_Soyad { get; set; }
    public string? TelNo { get; set; }
    public string? Email { get; set; }
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public List<DepoTedarikci> DepoTedarikcis { get; set; }

}