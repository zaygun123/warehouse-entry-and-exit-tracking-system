using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class SiparisController : CustomBaseController
{
    private readonly ISiparisService _siparisService;
    private readonly IMapper _mapper;
    public SiparisController(ISiparisService siparisService,IMapper mapper)
    {
        _siparisService=siparisService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _siparisService.GetAktif();
        var siparises=_mapper.Map<List<SiparisDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<SiparisDto>>.Success(200,siparises));
    }    
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _siparisService.GetById(id);
        var siparis = _mapper.Map<SiparisDto>(entity);
        return CreateActionResult(CustomResponseDto<SiparisDto>.Success(200,siparis));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterSevkiyat(int id)
    {
        var entitys = await _siparisService.GetFilterSevkiyat(id);
        var siparis = _mapper.Map<List<SiparisDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<SiparisDto>>.Success(200,siparis));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetSiparisWithStok(int id)
    {
        var siparis=await _siparisService.GetSiparisWithStok(id);
        var stokList=new List<Stok>();
        foreach(var item in siparis.SiparisStoks)
        {
            stokList.Add(item.Stok);
        }
        var siparisdto=_mapper.Map<SiparisDto>(siparis);
        var stokdto=_mapper.Map<List<StokDto>>(stokList.ToList());
        siparisdto.StokDtos = stokdto;
        return CreateActionResult(CustomResponseDto<SiparisDto>.Success(200,siparisdto));
    }
    [HttpPost]
    public async Task<IActionResult> Save(SiparisCreateDto SiparisDto)
    {
        var entity=_mapper.Map<Siparis>(SiparisDto);
        _siparisService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(SiparisUpdateDto SiparisDto)
    {
        var entity=_mapper.Map<Siparis>(SiparisDto);
        _siparisService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _siparisService.GetById(id);
        entity.Passive=true;
        _siparisService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}