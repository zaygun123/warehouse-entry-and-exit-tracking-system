using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class ImageController : CustomBaseController
{
    private readonly IImageService _imageService;
    private readonly IMapper _mapper;
    public ImageController(IImageService imageService,IMapper mapper)
    {
        _imageService=imageService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _imageService.GetAktif();
        var images=_mapper.Map<List<ImageDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<ImageDto>>.Success(200,images));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _imageService.GetById(id);
        var image = _mapper.Map<ImageDto>(entity);
        return CreateActionResult(CustomResponseDto<ImageDto>.Success(200,image));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterUrun(int id)
    {
        var entitys = await _imageService.GetFilterUrun(id);
        var image = _mapper.Map<List<ImageDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<ImageDto>>.Success(200,image));
    }
    [HttpPost]
    public async Task<IActionResult> Save(ImageCreateDto ImageDto)
    {
        var entity=_mapper.Map<Image>(ImageDto);
        _imageService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(ImageUpdateDto ImageDto)
    {
        var entity=_mapper.Map<Image>(ImageDto);
        _imageService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _imageService.GetById(id);
        entity.Passive=true;
        _imageService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}