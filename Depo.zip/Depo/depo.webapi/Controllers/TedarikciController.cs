using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class TedarikciController : CustomBaseController
{
    private readonly ITedarikciService _tedarikciService;
    private readonly IMapper _mapper;
    public TedarikciController(ITedarikciService tedarikciService,IMapper mapper)
    {
        _tedarikciService=tedarikciService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _tedarikciService.GetAktif();
        var tedarikcis=_mapper.Map<List<TedarikciDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<TedarikciDto>>.Success(200,tedarikcis));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _tedarikciService.GetById(id);
        var tedarikci = _mapper.Map<TedarikciDto>(entity);
        return CreateActionResult(CustomResponseDto<TedarikciDto>.Success(200,tedarikci));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterDepo(int id)
    {
        var entitys = await _tedarikciService.GetFilterDepo(id);
        var tedarikcis = _mapper.Map<List<TedarikciDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<TedarikciDto>>.Success(200,tedarikcis));
    }
    [HttpPost]
    public async Task<IActionResult> Save(TedarikciCreateDto TedarikciDto)
    {
        var entity=_mapper.Map<Tedarikci>(TedarikciDto);
        _tedarikciService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(TedarikciUpdateDto TedarikciDto)
    {
        var entity=_mapper.Map<Tedarikci>(TedarikciDto);
        _tedarikciService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _tedarikciService.GetById(id);
        entity.Passive=true;
        _tedarikciService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}