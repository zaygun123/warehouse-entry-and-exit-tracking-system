using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class KategoriController : CustomBaseController
{
    private readonly IKategoriService _kategoriService;
    private readonly IMapper _mapper;
    public KategoriController(IKategoriService kategoriService,IMapper mapper)
    {
        _kategoriService=kategoriService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _kategoriService.GetAktif();
        var kategoris=_mapper.Map<List<KategoriDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<KategoriDto>>.Success(200,kategoris));
    }
    [HttpPost]
    public async Task<IActionResult> Save(KategoriCreateDto KategoriDto)
    {
        var entity=_mapper.Map<Kategori>(KategoriDto);
        _kategoriService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _kategoriService.GetById(id);
        var kategori = _mapper.Map<KategoriDto>(entity);
        return CreateActionResult(CustomResponseDto<KategoriDto>.Success(200,kategori));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterUrun(int id)
    {
        var entitys = await _kategoriService.GetFilterUrun(id);
        var kategori = _mapper.Map<GetKategoriWithUrunDto>(entitys);
        return CreateActionResult(CustomResponseDto<GetKategoriWithUrunDto>.Success(200,kategori));
    }
    [HttpPut]
    public async Task<IActionResult> Update(KategoriUpdateDto KategoriDto)
    {
        var entity=_mapper.Map<Kategori>(KategoriDto);
        _kategoriService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _kategoriService.GetById(id);
        entity.Passive=true;
        _kategoriService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}