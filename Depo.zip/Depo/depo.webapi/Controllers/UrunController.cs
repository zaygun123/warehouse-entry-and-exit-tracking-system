using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class UrunController : CustomBaseController
{
    private readonly IUrunService _urunService;
    private readonly IMapper _mapper;
    public UrunController(IUrunService urunService,IMapper mapper)
    {
        _urunService=urunService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _urunService.GetAktif();
        var uruns=_mapper.Map<List<UrunDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<UrunDto>>.Success(200,uruns));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _urunService.GetById(id);
        var urun = _mapper.Map<GetFilterUrunDto>(entity);
        return CreateActionResult(CustomResponseDto<GetFilterUrunDto>.Success(200,urun));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetUrunWithEnvanter(int id)
    {
        var urun=await _urunService.GetUrunWithEnvanter(id);
        var envanterList=new List<Envanter>();
        foreach(var item in urun.EnvanterUruns)
        {
            envanterList.Add(item.Envanter);
        }
        var urundto=_mapper.Map<UrunDto>(urun);
        var envanterdto=_mapper.Map<List<EnvanterDto>>(envanterList.ToList());
        urundto.EnvanterDtos = envanterdto;
        return CreateActionResult(CustomResponseDto<UrunDto>.Success(200,urundto));
    }
    [HttpPost]
    public async Task<IActionResult> Save(UrunCreateDto UrunDto)
    {
        var entity=_mapper.Map<Urun>(UrunDto);
        _urunService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    
    [HttpPut]
    public async Task<IActionResult> Update(UrunUpdateDto UrunDto)
    {
        var entity=_mapper.Map<Urun>(UrunDto);
        _urunService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _urunService.GetById(id);
        entity.Passive=true;
        _urunService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}