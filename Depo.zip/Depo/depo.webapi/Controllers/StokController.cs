using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class StokController : CustomBaseController
{
    private readonly IStokService _stokService;
    private readonly IMapper _mapper;
    public StokController(IStokService stokService,IMapper mapper)
    {
        _stokService=stokService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _stokService.GetAktif();
        var stoks=_mapper.Map<List<StokDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<StokDto>>.Success(200,stoks));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _stokService.GetById(id);
        var stok = _mapper.Map<StokDto>(entity);
        return CreateActionResult(CustomResponseDto<StokDto>.Success(200,stok));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetStoksByRafId(int id)
    {
        var entitys = await _stokService.GetStoksByRafId(id);
        var stok = _mapper.Map<List<StokDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<StokDto>>.Success(200,stok));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterSiparis(int id)
    {
        var entitys = await _stokService.GetFilterSiparis(id);
        var stoks = _mapper.Map<List<StokDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<StokDto>>.Success(200,stoks));
    }
    [HttpPost]
    public async Task<IActionResult> Save(StokCreateDto StokDto)
    {
        var entity=_mapper.Map<Stok>(StokDto);
        _stokService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(StokUpdateDto StokDto)
    {
        var entity=_mapper.Map<Stok>(StokDto);
        _stokService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _stokService.GetById(id);
        entity.Passive=true;
        _stokService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}