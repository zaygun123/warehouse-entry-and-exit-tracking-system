using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class EnvanterTipiController:CustomBaseController
{
    private readonly IEnvanterTipiService _envanterTipiService;
    private readonly IMapper _mapper;
    public EnvanterTipiController(IEnvanterTipiService envanterTipiService,IMapper mapper)
    {
        _envanterTipiService=envanterTipiService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _envanterTipiService.GetAktif();
        var envantertipis=_mapper.Map<List<EnvanterTipiDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<EnvanterTipiDto>>.Success(200,envantertipis));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _envanterTipiService.GetById(id);
        var envantertipi = _mapper.Map<EnvanterTipiDto>(entity);
        return CreateActionResult(CustomResponseDto<EnvanterTipiDto>.Success(200,envantertipi));
    }
    [HttpPost]
    public async Task<IActionResult> Save(EnvanterTipiCreateDto EnvanterTipiDto)
    {
        var entity=_mapper.Map<EnvanterTipi>(EnvanterTipiDto);
        _envanterTipiService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(EnvanterTipiUpdateDto EnvanterTipiDto)
    {
        var entity=_mapper.Map<EnvanterTipi>(EnvanterTipiDto);
        _envanterTipiService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _envanterTipiService.GetById(id);
        entity.Passive=true;
        _envanterTipiService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }

}