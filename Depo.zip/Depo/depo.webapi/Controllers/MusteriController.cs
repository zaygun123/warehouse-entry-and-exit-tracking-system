using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class MusteriController : CustomBaseController
{
    private readonly IMusteriService _musteriService;
    private readonly IMapper _mapper;
    public MusteriController(IMusteriService musteriService,IMapper mapper)
    {
        _musteriService=musteriService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _musteriService.GetAktif();
        var musteris=_mapper.Map<List<MusteriDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<MusteriDto>>.Success(200,musteris));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _musteriService.GetById(id);
        var musteri = _mapper.Map<MusteriDto>(entity);
        return CreateActionResult(CustomResponseDto<MusteriDto>.Success(200,musteri));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterSiparis(int id)
    {
        var entity=await _musteriService.GetFilterSiparis(id);
        var musteri=_mapper.Map<MusteriWithSiparisDto>(entity);
        return CreateActionResult(CustomResponseDto<MusteriWithSiparisDto>.Success(200,musteri));
    }
    [HttpPost]
    public async Task<IActionResult> Save(MusteriCreateDto MusteriDto)
    {
        var entity=_mapper.Map<Musteri>(MusteriDto);
        _musteriService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(MusteriUpdateDto MusteriDto)
    {
        var entity=_mapper.Map<Musteri>(MusteriDto);
        _musteriService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _musteriService.GetById(id);
        entity.Passive=true;
        _musteriService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}