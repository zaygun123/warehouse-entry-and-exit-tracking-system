using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class PersonelController : CustomBaseController
{
    private readonly IPersonelService _personelService;
    private readonly IMapper _mapper;
    public PersonelController(IPersonelService personelService,IMapper mapper)
    {
        _personelService=personelService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _personelService.GetAktif();
        var personels=_mapper.Map<List<PersonelDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<PersonelDto>>.Success(200,personels));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _personelService.GetById(id);
        var personel = _mapper.Map<PersonelDto>(entity);
        return CreateActionResult(CustomResponseDto<PersonelDto>.Success(200,personel));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterPersonel(int id)
    {
        var entity=await _personelService.GetFilterStokHareketleri(id);
        var personel=_mapper.Map<PersonelWithStokHareketleriDto>(entity);
        return CreateActionResult(CustomResponseDto<PersonelWithStokHareketleriDto>.Success(200,personel));
    }
    [HttpPost]
    public async Task<IActionResult> Save(PersonelCreateDto PersonelDto)
    {
        var entity=_mapper.Map<Personel>(PersonelDto);
        _personelService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(PersonelUpdateDto PersonelDto)
    {
        var entity=_mapper.Map<Personel>(PersonelDto);
        _personelService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _personelService.GetById(id);
        entity.Passive=true;
        _personelService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}