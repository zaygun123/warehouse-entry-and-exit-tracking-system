using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class EskiStokMiktariController : CustomBaseController
{
    private readonly IEskiStokMiktariService _eskiStokMiktariService;
    private readonly IMapper _mapper;
    public EskiStokMiktariController(IEskiStokMiktariService eskiStokMiktariService,IMapper mapper)
    {
        _eskiStokMiktariService=eskiStokMiktariService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _eskiStokMiktariService.GetAktif();
        var eskistokmiktaris=_mapper.Map<List<EskiStokMiktariDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<EskiStokMiktariDto>>.Success(200,eskistokmiktaris));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _eskiStokMiktariService.GetById(id);
        var eskistokmiktari = _mapper.Map<EskiStokMiktariDto>(entity);
        return CreateActionResult(CustomResponseDto<EskiStokMiktariDto>.Success(200,eskistokmiktari));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetsStokMiktariByStokId(int id)
    {
        var entitys = await _eskiStokMiktariService.GetsStokMiktariByStokId(id);
        var eskistokmiktari = _mapper.Map<List<EskiStokMiktariDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<EskiStokMiktariDto>>.Success(200,eskistokmiktari));
    }
    [HttpPost]
    public async Task<IActionResult> Save(EskiStokMiktariCreateDto EskiStokMiktariDto)
    {
        var entity=_mapper.Map<EskiStokMiktari>(EskiStokMiktariDto);
        _eskiStokMiktariService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(EskiStokMiktariUpdateDto EskiStokMiktariDto)
    {
        var entity=_mapper.Map<EskiStokMiktari>(EskiStokMiktariDto);
        _eskiStokMiktariService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _eskiStokMiktariService.GetById(id);
        entity.Passive=true;
        _eskiStokMiktariService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}