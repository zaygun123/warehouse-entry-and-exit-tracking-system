using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;
[ApiController]
[Route("[Controller]")]
public class EnvanterController:CustomBaseController
{
    private readonly IEnvanterService _envanterService;
    private readonly IMapper _mapper;

    public EnvanterController(IEnvanterService envanterService, IMapper mapper)
    {
        _envanterService=envanterService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _envanterService.GetAktif();
        var envanters=_mapper.Map<List<EnvanterDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<EnvanterDto>>.Success(200,envanters));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _envanterService.GetById(id);
        var envanter = _mapper.Map<EnvanterDto>(entity);
        return CreateActionResult(CustomResponseDto<EnvanterDto>.Success(200,envanter));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterUrun(int id)
    {
        var entitys = await _envanterService.GetFilterUrun(id);
        var envanters = _mapper.Map<List<EnvanterDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<EnvanterDto>>.Success(200,envanters));
    }
    [HttpPost]
    public async Task<IActionResult> Save(EnvanterCreateDto EnvanterDto)
    {
        var entity=_mapper.Map<Envanter>(EnvanterDto);
        _envanterService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(EnvanterUpdateDto EnvanterDto)
    {
        var entity=_mapper.Map<Envanter>(EnvanterDto);
        _envanterService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _envanterService.GetById(id);
        entity.Passive=true;
        _envanterService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}