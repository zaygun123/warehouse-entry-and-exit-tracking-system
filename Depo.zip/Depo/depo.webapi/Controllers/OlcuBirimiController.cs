using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class OlcuBirimiController : CustomBaseController
{
    private readonly IOlcuBirimiService _olcuBirimiService;
    private readonly IMapper _mapper;
    public OlcuBirimiController(IOlcuBirimiService olcuBirimiService,IMapper mapper)
    {
        _olcuBirimiService=olcuBirimiService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _olcuBirimiService.GetAktif();
        var olcubirimis=_mapper.Map<List<OlcuBirimiDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<OlcuBirimiDto>>.Success(200,olcubirimis));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _olcuBirimiService.GetById(id);
        var olcubirimi = _mapper.Map<OlcuBirimiDto>(entity);
        return CreateActionResult(CustomResponseDto<OlcuBirimiDto>.Success(200,olcubirimi));
    }
    [HttpPost]
    public async Task<IActionResult> Save(OlcuBirimiCreateDto OlcuBirimiDto)
    {
        var entity=_mapper.Map<OlcuBirimi>(OlcuBirimiDto);
        _olcuBirimiService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(OlcuBirimiUpdateDto OlcuBirimiDto)
    {
        var entity=_mapper.Map<OlcuBirimi>(OlcuBirimiDto);
        _olcuBirimiService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _olcuBirimiService.GetById(id);
        entity.Passive=true;
        _olcuBirimiService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}