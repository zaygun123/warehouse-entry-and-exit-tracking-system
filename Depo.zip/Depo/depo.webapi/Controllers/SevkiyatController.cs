using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class SevkiyatController : CustomBaseController
{
    private readonly ISevkiyatService _sevkiyatService;
    private readonly IMapper _mapper;
    public SevkiyatController(ISevkiyatService sevkiyatService,IMapper mapper)
    {
        _sevkiyatService=sevkiyatService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _sevkiyatService.GetAktif();
        var sevkiyats=_mapper.Map<List<SevkiyatDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<SevkiyatDto>>.Success(200,sevkiyats));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _sevkiyatService.GetById(id);
        var sevkiyat = _mapper.Map<SevkiyatDto>(entity);
        return CreateActionResult(CustomResponseDto<SevkiyatDto>.Success(200,sevkiyat));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterSiparis(int id)
    {
        var entitys = await _sevkiyatService.GetFilterSiparis(id);
        var sevkiyat = _mapper.Map<SevkiyatWithSiparisDto>(entitys);
        return CreateActionResult(CustomResponseDto<SevkiyatWithSiparisDto>.Success(200,sevkiyat));
    }
    [HttpPost]
    public async Task<IActionResult> Save(SevkiyatCreateDto SevkiyatDto)
    {
        var entity=_mapper.Map<Sevkiyat>(SevkiyatDto);
        _sevkiyatService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(SevkiyatUpdateDto SevkiyatDto)
    {
        var entity=_mapper.Map<Sevkiyat>(SevkiyatDto);
        _sevkiyatService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _sevkiyatService.GetById(id);
        entity.Passive=true;
        _sevkiyatService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}