using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class RafController : CustomBaseController
{
    private readonly IRafService _rafService;
    private readonly IMapper _mapper;
    public RafController(IRafService rafService,IMapper mapper)
    {
        _rafService=rafService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _rafService.GetAktif();
        var rafs=_mapper.Map<List<RafDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<RafDto>>.Success(200,rafs));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _rafService.GetById(id);
        var raf = _mapper.Map<RafDto>(entity);
        return CreateActionResult(CustomResponseDto<RafDto>.Success(200,raf));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetRafsByDepoId(int id)
    {
        var entitys = await _rafService.GetRafsByDepoId(id);
        var raf = _mapper.Map<List<RafDto>>(entitys);
        return CreateActionResult(CustomResponseDto<List<RafDto>>.Success(200,raf));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterStok(int id)
    {
        var entity=await _rafService.GetFilterStok(id);
        var raf=_mapper.Map<RafWithStokDto>(entity);
        return CreateActionResult(CustomResponseDto<RafWithStokDto>.Success(200,raf));
    }
    [HttpPost]
    public async Task<IActionResult> Save(RafCreateDto RafDto)
    {
        var entity=_mapper.Map<Raf>(RafDto);
        _rafService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(RafUpdateDto RafDto)
    {
        var entity=_mapper.Map<Raf>(RafDto);
        _rafService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _rafService.GetById(id);
        entity.Passive=true;
        _rafService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}