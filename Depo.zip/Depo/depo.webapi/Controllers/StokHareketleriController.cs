using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class StokHareketleriController : CustomBaseController
{
    private readonly IStokHareketleriService _stokHareketleriService;
    private readonly IMapper _mapper;
    public StokHareketleriController(IStokHareketleriService stokHareketleriService,IMapper mapper)
    {
        _stokHareketleriService=stokHareketleriService;
        _mapper=mapper;
    }
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _stokHareketleriService.GetAktif();
        var stokhareketleris=_mapper.Map<List<StokHareketleriDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<StokHareketleriDto>>.Success(200,stokhareketleris));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _stokHareketleriService.GetById(id);
        var stokhareketleri = _mapper.Map<StokHareketleriDto>(entity);
        return CreateActionResult(CustomResponseDto<StokHareketleriDto>.Success(200,stokhareketleri));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetStokHareketisByStokId(int id)
    {
        var entity= await _stokHareketleriService.GetStokHareketisByStokId(id);
        var stokhareketleri=_mapper.Map<List<StokHareketleriDto>>(entity.ToList());
        return CreateActionResult(CustomResponseDto<List<StokHareketleriDto>>.Success(200,stokhareketleri));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetStokHareketlerisByPersonelId(int id)
    {
        var entity= await _stokHareketleriService.GetStokHareketlerisByPersonelId(id);
        var stokhareketleri=_mapper.Map<List<StokHareketleriDto>>(entity.ToList());
        return CreateActionResult(CustomResponseDto<List<StokHareketleriDto>>.Success(200,stokhareketleri));
    }
    
    [HttpPost]
    public async Task<IActionResult> Save(StokHareketleriCreateDto StokHareketleriDto)
    {
        var entity=_mapper.Map<StokHareketleri>(StokHareketleriDto);
        _stokHareketleriService.Create(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(StokHareketleriUpdateDto StokHareketleriDto)
    {
        var entity=_mapper.Map<StokHareketleri>(StokHareketleriDto);
        _stokHareketleriService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _stokHareketleriService.GetById(id);
        entity.Passive=true;
        _stokHareketleriService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
}