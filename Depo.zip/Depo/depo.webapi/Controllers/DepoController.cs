using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System.Collections.Generic; 
using depo.webapi.Dtos;
using depo.entity;
using depo.business.Abstract;
using depo.business.Concrete;

namespace depo.webapi.Controllers;


[ApiController]
[Route("[Controller]")]
public class DepoController : CustomBaseController
{
    private readonly IDepoService _depoService;
    private readonly IMapper _mapper;
    public DepoController(IDepoService depoService,IMapper mapper)
    {
        _depoService=depoService;
        _mapper=mapper;
    }

    [HttpGet]
    public async Task<IActionResult> All()
    {
        var entitys=await _depoService.GetAktif();
        var depos=_mapper.Map<List<DepoDto>>(entitys.ToList());
        return CreateActionResult(CustomResponseDto<List<DepoDto>>.Success(200,depos));
    }
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var entity = await _depoService.GetById(id);
        var depo = _mapper.Map<DepoDto>(entity);
        return CreateActionResult(CustomResponseDto<DepoDto>.Success(200,depo));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetDepoWithTedarikci(int id)
    {
        var depo=await _depoService.GetDepoWithTedarikci(id);
        var tedarikciList=new List<Tedarikci>();
        foreach(var item in depo.DepoTedarikcis)
        {
            tedarikciList.Add(item.Tedarikci);
        }
        var depodto=_mapper.Map<DepoDto>(depo);
        var tedarikcidto=_mapper.Map<List<TedarikciDto>>(tedarikciList.ToList());
        depodto.TedarikciDtos = tedarikcidto;
        return CreateActionResult(CustomResponseDto<DepoDto>.Success(200,depodto));
    }
    [HttpGet("[action]/{id}")]
    public async Task<IActionResult> GetFilterPersonel(int id)
    {
        var entity=await _depoService.GetFilterPersonel(id);
        var depo=_mapper.Map<DepoWithPersonelDto>(entity);
        return CreateActionResult(CustomResponseDto<DepoWithPersonelDto>.Success(200,depo));
    }
    [HttpPost]
    public async Task<IActionResult> Save(DepoCreateDto DepoDto)
    {
        var depo=_mapper.Map<Depo>(DepoDto);
        _depoService.Create(depo);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpPut]
    public async Task<IActionResult> Update(DepoUpdateDto DepoDto)
    {
        var depo=_mapper.Map<Depo>(DepoDto);
        _depoService.Update(depo);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
    [HttpDelete("{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var entity=await _depoService.GetById(id);
        entity.Passive=true;
        _depoService.Update(entity);
        return CreateActionResult(CustomResponseDto<NoContentDto>.Success(204));
    }
   
}