namespace depo.webapi.Dtos;
public class EnvanterTipiUpdateDto
{
    public int? Id {get; set;}
    public string? envantertipi { get; set; }

}