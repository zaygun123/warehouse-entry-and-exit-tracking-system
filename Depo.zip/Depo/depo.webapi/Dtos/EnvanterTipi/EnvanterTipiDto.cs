namespace depo.webapi.Dtos;
public class EnvanterTipiDto
{
    public int? Id {get; set;}
    public string? envantertipi { get; set; }

}