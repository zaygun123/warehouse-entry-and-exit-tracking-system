namespace depo.webapi.Dtos;
public class EnvanterTipiCreateDto
{
    public string? envantertipi { get; set; }

}