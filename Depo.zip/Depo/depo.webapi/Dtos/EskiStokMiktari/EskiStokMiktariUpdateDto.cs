namespace depo.webapi.Dtos;
public class EskiStokMiktariUpdateDto
{
    public int? Id {get; set;}
    public double? EskiStok { get; set; }

}