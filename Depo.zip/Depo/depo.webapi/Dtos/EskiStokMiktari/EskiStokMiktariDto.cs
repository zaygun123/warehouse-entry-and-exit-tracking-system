namespace depo.webapi.Dtos;
public class EskiStokMiktariDto
{
    public int? Id {get; set;}
    public double? EskiStok { get; set; }
}