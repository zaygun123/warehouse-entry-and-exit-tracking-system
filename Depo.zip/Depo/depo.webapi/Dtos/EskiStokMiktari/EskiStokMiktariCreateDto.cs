namespace depo.webapi.Dtos;
public class EskiStokMiktariCreateDto
{
    public double? EskiStok { get; set; }
   
}