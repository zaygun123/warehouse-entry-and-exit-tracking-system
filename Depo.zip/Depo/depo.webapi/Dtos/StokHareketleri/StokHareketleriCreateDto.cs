namespace depo.webapi.Dtos;
public class StokHareketleriCreateDto
{
    public double? StokMiktari { get; set; }
    public DateTime Tarih { get; set; }
    public double? ToplamAgirlik { get; set; }
    public int? Durum { get; set; }    
}