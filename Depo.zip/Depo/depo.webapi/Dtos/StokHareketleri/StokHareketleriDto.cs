namespace depo.webapi.Dtos;
public class StokHareketleriDto
{
    public int? Id {get; set;}
    public double? StokMiktari { get; set; }
    public DateTime Tarih { get; set; }
    public double? ToplamAgirlik { get; set; }
    public int? Durum { get; set; }
    public int? StokId { get; set; }
    public StokDto Stok { get; set; }

}