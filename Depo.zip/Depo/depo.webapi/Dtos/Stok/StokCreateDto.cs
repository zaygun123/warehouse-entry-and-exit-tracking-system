namespace depo.webapi.Dtos;
public class StokCreateDto
{
    public string? SKUno { get; set; }
    public double? StokMiktari { get; set; }
    public double? MinStok { get; set; }
    public double? MaxStok { get; set; }
    public double? KritikStokMiktari { get; set; }    
}