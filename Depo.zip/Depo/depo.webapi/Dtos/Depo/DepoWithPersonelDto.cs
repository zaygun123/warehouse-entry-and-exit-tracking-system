namespace depo.webapi.Dtos;
public class DepoWithPersonelDto:DepoDto
{
    public List<PersonelDto> Personels { get; set; }
}