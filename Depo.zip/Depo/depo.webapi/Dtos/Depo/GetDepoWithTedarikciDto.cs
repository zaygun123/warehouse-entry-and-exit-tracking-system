namespace depo.webapi.Dtos;
public class GetDepoWithTedarikciDto
{
    public List<TedarikciDto> TedarikciDtos { get; set; }
   
}