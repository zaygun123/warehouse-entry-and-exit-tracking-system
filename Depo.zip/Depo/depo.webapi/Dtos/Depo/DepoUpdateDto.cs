namespace depo.webapi.Dtos;
public class DepoUpdateDto
{
    public int? Id { get; set; }
    public string? Depo_adi { get; set; }
    public double Doluluk_orani { get; set; }
}