namespace depo.webapi.Dtos;
public class DepoCreateDto
{
    public string? Depo_adi { get; set; }
    public double Doluluk_orani { get; set; }
}