namespace depo.webapi.Dtos;
public class DepoDto:GetDepoWithTedarikciDto
{
    public int? Id { get; set; }
    public string? Depo_adi { get; set; }
    public double Doluluk_orani { get; set; }
}