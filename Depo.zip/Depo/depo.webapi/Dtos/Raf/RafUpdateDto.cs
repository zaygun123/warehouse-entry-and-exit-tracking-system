namespace depo.webapi.Dtos;
public class RafUpdateDto
{
    public int? Id {get; set;}
    public string? RafNo { get; set; }

}