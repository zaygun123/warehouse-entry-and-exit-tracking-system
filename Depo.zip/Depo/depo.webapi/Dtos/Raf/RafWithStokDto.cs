namespace depo.webapi.Dtos;
public class RafWithStokDto:RafDto
{
    public List<StokDto> Stoks { get; set; }
}