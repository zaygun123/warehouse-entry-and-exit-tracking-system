namespace depo.webapi.Dtos;
public class RafCreateDto
{
    public string? RafNo { get; set; }
    
}