namespace depo.webapi.Dtos;
public class RafDto
{
    public int? Id {get; set;}
    public string? RafNo { get; set; }

}