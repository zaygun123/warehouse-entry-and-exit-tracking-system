namespace depo.webapi.Dtos;
public class ImageCreateDto
{
    public string? image { get; set; }    
   
}