namespace depo.webapi.Dtos;
public class ImageDto
{
    public int? Id {get; set;}
    public string? image { get; set; }    
}