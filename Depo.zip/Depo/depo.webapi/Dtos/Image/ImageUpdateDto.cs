namespace depo.webapi.Dtos;
public class ImageUpdateDto
{
    public int? Id {get; set;}
    public string? image { get; set; }    

}