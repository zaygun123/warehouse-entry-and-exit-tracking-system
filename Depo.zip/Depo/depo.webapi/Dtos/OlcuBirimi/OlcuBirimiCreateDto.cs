namespace depo.webapi.Dtos;
public class OlcuBirimiCreateDto
{
    public string? olcubirimi { get; set; }
    
}