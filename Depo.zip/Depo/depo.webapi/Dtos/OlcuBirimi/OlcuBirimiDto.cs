namespace depo.webapi.Dtos;
public class OlcuBirimiDto
{
    public int? Id {get; set;}
    public string? olcubirimi { get; set; }

}