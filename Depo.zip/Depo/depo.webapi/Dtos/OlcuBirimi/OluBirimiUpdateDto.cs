namespace depo.webapi.Dtos;
public class OlcuBirimiUpdateDto
{
    public int? Id {get; set;}
    public string? olcubirimi { get; set; }

}