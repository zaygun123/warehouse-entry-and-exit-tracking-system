namespace depo.webapi.Dtos;
public class PersonelWithStokHareketleriDto:PersonelDto
{
    public List<StokHareketleriDto> StokHareketleris { get; set; }
}