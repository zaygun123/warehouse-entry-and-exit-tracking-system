namespace depo.webapi.Dtos;
public class PersonelUpdateDto
{
    public int? Id {get; set;}
    public string? Ad { get; set; }
    public string? TelNo { get; set; }
    public string? Email { get; set; }
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
}