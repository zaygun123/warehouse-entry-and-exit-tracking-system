namespace depo.webapi.Dtos;
public class MusteriWithSiparisDto:MusteriDto
{
    public List<SiparisDto> Siparises { get; set; }
}