namespace depo.webapi.Dtos;
public class NoContentDto
{
    
}