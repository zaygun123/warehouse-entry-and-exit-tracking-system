namespace depo.webapi.Dtos;
public class SevkiyatWithSiparisDto:SevkiyatDto
{
    public string? SevkiyatNo { get; set; }
    public DateTime Tarih { get; set; }
    public List<SiparisDto> Siparises { get; set; }
}