namespace depo.webapi.Dtos;
public class SevkiyatDto
{
    public int? Id {get; set;}
    public string? SevkiyatNo { get; set; }
    public DateTime Tarih { get; set; }
    
}