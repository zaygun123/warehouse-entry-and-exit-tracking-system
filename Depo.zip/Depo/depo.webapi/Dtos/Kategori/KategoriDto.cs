namespace depo.webapi.Dtos;
public class KategoriDto
{
    public int? Id {get; set;}
    public string? kategoriadi { get; set; }

}