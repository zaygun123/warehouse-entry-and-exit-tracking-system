namespace depo.webapi.Dtos;
public class KategoriCreateDto
{
     public string? kategoriadi { get; set; }
   
}