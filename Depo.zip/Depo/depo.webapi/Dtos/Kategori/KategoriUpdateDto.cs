namespace depo.webapi.Dtos;
public class KategoriUpdateDto
{
    public int? Id {get; set;}
    public string? kategoriadi { get; set; }

}