namespace depo.webapi.Dtos;
public class GetKategoriWithUrunDto:KategoriDto
{
    public int? Id {get; set;}
    public string? kategoriadi { get; set; }
    public List<UrunDto> Uruns { get; set; }
}