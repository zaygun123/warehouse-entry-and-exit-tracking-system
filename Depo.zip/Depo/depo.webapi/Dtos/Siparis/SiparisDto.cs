namespace depo.webapi.Dtos;
public class SiparisDto:GetSiparisWithStokDto
{
    public int? Id {get; set;}
    public string? Adres { get; set; }
    public string? Il { get; set; }
    public string? Ilce { get; set; }
    public string? Ulke { get; set; }
    public string? SiparisNo { get; set; }
    public DateTime Tarih { get; set; }
    public double? SiparisAgirligi { get; set; }
    public double? Adet { get; set; }
    public int? siparisDurumu { get; set; }

}