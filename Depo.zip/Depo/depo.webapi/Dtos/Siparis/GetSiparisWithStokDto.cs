namespace depo.webapi.Dtos;
public class GetSiparisWithStokDto
{
    public List<StokDto> StokDtos { get; set; }

}