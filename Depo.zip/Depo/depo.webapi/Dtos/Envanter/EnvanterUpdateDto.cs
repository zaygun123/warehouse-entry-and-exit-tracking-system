namespace depo.webapi.Dtos;
public class EnvanterUpdateDto
{
    public int? Id {get; set;}
    public string? Ad { get; set; }
}