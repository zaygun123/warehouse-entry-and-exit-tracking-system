namespace depo.webapi.Dtos;
public class EnvanterCreateDto
{
 public string? Ad { get; set; }   
}