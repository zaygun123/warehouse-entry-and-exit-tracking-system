namespace depo.webapi.Dtos;
public class EnvanterDto
{
    public int? Id { get; set; }
    public string? Ad { get; set; }
}