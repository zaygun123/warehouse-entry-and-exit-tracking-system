namespace depo.webapi.Dtos;
public class UrunCreateDto
{
    public string? Ad { get; set; }
    public string? Kod { get; set; }
    public string? Fiyat { get; set; }
    public double? Agirlik { get; set; }
    public string? En { get; set; }
    public string? Boy { get; set; }
    public string? Derinlik { get; set; }
    public string? Barkod { get; set; }
    public string? HataSebebi { get; set; }
    public string? IadeSebebi { get; set; }
    public DateTime Tarih { get; set; }
    public string? image { get; set; }   
}