namespace depo.webapi.Dtos;
public class GetUrunWithEnvanterDto
{
    public List<EnvanterDto> EnvanterDtos { get; set; }
   
}