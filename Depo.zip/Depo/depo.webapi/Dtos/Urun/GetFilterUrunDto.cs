namespace depo.webapi.Dtos;
public class GetFilterUrunDto
{
    public int? Id {get; set;}
    public string? Ad { get; set; }
    public string? Kod { get; set; }
    public string? Fiyat { get; set; }
    public double? Agirlik { get; set; }
    public string? Barkod { get; set; }
}