﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace depo.data.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Depos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Depoadi = table.Column<string>(name: "Depo_adi", type: "nvarchar(max)", nullable: true),
                    Dolulukorani = table.Column<double>(name: "Doluluk_orani", type: "float", nullable: false),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Depos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EnvanterTipis",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    envantertipi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EnvanterTipis", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Kategoris",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    kategoriadi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Kategoris", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Musteris",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MusteriNo = table.Column<int>(type: "int", nullable: true),
                    AdSoyad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TelNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Adres = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Il = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ilce = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ulke = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Musteris", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OlcuBirimis",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    olcubirimi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OlcuBirimis", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Sevkiyats",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SevkiyatNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tarih = table.Column<DateTime>(type: "datetime2", nullable: false),
                    sevkiyatDurumu = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sevkiyats", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Tedarikcis",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AdSoyad = table.Column<string>(name: "Ad_Soyad", type: "nvarchar(max)", nullable: true),
                    TelNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Adres = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Il = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ilce = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ulke = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tedarikcis", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Personels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TelNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Adres = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Il = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ilce = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ulke = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DepoId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Personels", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Personels_Depos_DepoId",
                        column: x => x.DepoId,
                        principalTable: "Depos",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Rafs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RafNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DepoId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rafs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Rafs_Depos_DepoId",
                        column: x => x.DepoId,
                        principalTable: "Depos",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Envanters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EnvanterTipiId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Envanters", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Envanters_EnvanterTipis_EnvanterTipiId",
                        column: x => x.EnvanterTipiId,
                        principalTable: "EnvanterTipis",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Siparises",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Adres = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Il = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ilce = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ulke = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SiparisNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tarih = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SiparisAgirligi = table.Column<double>(type: "float", nullable: true),
                    Adet = table.Column<double>(type: "float", nullable: true),
                    MusteriId = table.Column<int>(type: "int", nullable: true),
                    SevkiyatId = table.Column<int>(type: "int", nullable: true),
                    siparisDurumu = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Siparises", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Siparises_Musteris_MusteriId",
                        column: x => x.MusteriId,
                        principalTable: "Musteris",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Siparises_Sevkiyats_SevkiyatId",
                        column: x => x.SevkiyatId,
                        principalTable: "Sevkiyats",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "DepoTedarikci",
                columns: table => new
                {
                    DepoId = table.Column<int>(type: "int", nullable: false),
                    TedarikciId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DepoTedarikci", x => new { x.DepoId, x.TedarikciId });
                    table.ForeignKey(
                        name: "FK_DepoTedarikci_Depos_DepoId",
                        column: x => x.DepoId,
                        principalTable: "Depos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DepoTedarikci_Tedarikcis_TedarikciId",
                        column: x => x.TedarikciId,
                        principalTable: "Tedarikcis",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Uruns",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Kod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Fiyat = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Agirlik = table.Column<double>(type: "float", nullable: true),
                    En = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Boy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Derinlik = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Barkod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OlcuBirimiId = table.Column<int>(type: "int", nullable: true),
                    KategoriId = table.Column<int>(type: "int", nullable: true),
                    MusteriId = table.Column<int>(type: "int", nullable: true),
                    HataSebebi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IadeSebebi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tarih = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SiparisId = table.Column<int>(type: "int", nullable: true),
                    image = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DepoId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Uruns", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Uruns_Depos_DepoId",
                        column: x => x.DepoId,
                        principalTable: "Depos",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Uruns_Kategoris_KategoriId",
                        column: x => x.KategoriId,
                        principalTable: "Kategoris",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Uruns_Musteris_MusteriId",
                        column: x => x.MusteriId,
                        principalTable: "Musteris",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Uruns_OlcuBirimis_OlcuBirimiId",
                        column: x => x.OlcuBirimiId,
                        principalTable: "OlcuBirimis",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Uruns_Siparises_SiparisId",
                        column: x => x.SiparisId,
                        principalTable: "Siparises",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "EnvanterUrun",
                columns: table => new
                {
                    EnvanterId = table.Column<int>(type: "int", nullable: false),
                    UrunId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EnvanterUrun", x => new { x.EnvanterId, x.UrunId });
                    table.ForeignKey(
                        name: "FK_EnvanterUrun_Envanters_EnvanterId",
                        column: x => x.EnvanterId,
                        principalTable: "Envanters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EnvanterUrun_Uruns_UrunId",
                        column: x => x.UrunId,
                        principalTable: "Uruns",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Images",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    image = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UrunId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Images", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Images_Uruns_UrunId",
                        column: x => x.UrunId,
                        principalTable: "Uruns",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Stoks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SKUno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StokMiktari = table.Column<double>(type: "float", nullable: true),
                    MinStok = table.Column<double>(type: "float", nullable: true),
                    MaxStok = table.Column<double>(type: "float", nullable: true),
                    KritikStokMiktari = table.Column<double>(type: "float", nullable: true),
                    UrunId = table.Column<int>(type: "int", nullable: true),
                    DepoId = table.Column<int>(type: "int", nullable: true),
                    RafId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Stoks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Stoks_Depos_DepoId",
                        column: x => x.DepoId,
                        principalTable: "Depos",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Stoks_Rafs_RafId",
                        column: x => x.RafId,
                        principalTable: "Rafs",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Stoks_Uruns_UrunId",
                        column: x => x.UrunId,
                        principalTable: "Uruns",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SiparisStok",
                columns: table => new
                {
                    SiparisId = table.Column<int>(type: "int", nullable: false),
                    StokId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SiparisStok", x => new { x.SiparisId, x.StokId });
                    table.ForeignKey(
                        name: "FK_SiparisStok_Siparises_SiparisId",
                        column: x => x.SiparisId,
                        principalTable: "Siparises",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SiparisStok_Stoks_StokId",
                        column: x => x.StokId,
                        principalTable: "Stoks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "StokHareketleris",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StokMiktari = table.Column<double>(type: "float", nullable: true),
                    Tarih = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ToplamAgirlik = table.Column<double>(type: "float", nullable: true),
                    PersonelId = table.Column<int>(type: "int", nullable: true),
                    StokId = table.Column<int>(type: "int", nullable: true),
                    Durum = table.Column<int>(type: "int", nullable: true),
                    EskiStokMiktariId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StokHareketleris", x => x.Id);
                    table.ForeignKey(
                        name: "FK_StokHareketleris_Personels_PersonelId",
                        column: x => x.PersonelId,
                        principalTable: "Personels",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_StokHareketleris_Stoks_StokId",
                        column: x => x.StokId,
                        principalTable: "Stoks",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "EskiStokMiktaris",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EskiStok = table.Column<double>(type: "float", nullable: true),
                    StokId = table.Column<int>(type: "int", nullable: true),
                    StokHareketleriId = table.Column<int>(type: "int", nullable: true),
                    Passive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EskiStokMiktaris", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EskiStokMiktaris_StokHareketleris_StokHareketleriId",
                        column: x => x.StokHareketleriId,
                        principalTable: "StokHareketleris",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_EskiStokMiktaris_Stoks_StokId",
                        column: x => x.StokId,
                        principalTable: "Stoks",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_DepoTedarikci_TedarikciId",
                table: "DepoTedarikci",
                column: "TedarikciId");

            migrationBuilder.CreateIndex(
                name: "IX_Envanters_EnvanterTipiId",
                table: "Envanters",
                column: "EnvanterTipiId");

            migrationBuilder.CreateIndex(
                name: "IX_EnvanterUrun_UrunId",
                table: "EnvanterUrun",
                column: "UrunId");

            migrationBuilder.CreateIndex(
                name: "IX_EskiStokMiktaris_StokHareketleriId",
                table: "EskiStokMiktaris",
                column: "StokHareketleriId",
                unique: true,
                filter: "[StokHareketleriId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_EskiStokMiktaris_StokId",
                table: "EskiStokMiktaris",
                column: "StokId");

            migrationBuilder.CreateIndex(
                name: "IX_Images_UrunId",
                table: "Images",
                column: "UrunId");

            migrationBuilder.CreateIndex(
                name: "IX_Personels_DepoId",
                table: "Personels",
                column: "DepoId");

            migrationBuilder.CreateIndex(
                name: "IX_Rafs_DepoId",
                table: "Rafs",
                column: "DepoId");

            migrationBuilder.CreateIndex(
                name: "IX_Siparises_MusteriId",
                table: "Siparises",
                column: "MusteriId");

            migrationBuilder.CreateIndex(
                name: "IX_Siparises_SevkiyatId",
                table: "Siparises",
                column: "SevkiyatId");

            migrationBuilder.CreateIndex(
                name: "IX_SiparisStok_StokId",
                table: "SiparisStok",
                column: "StokId");

            migrationBuilder.CreateIndex(
                name: "IX_StokHareketleris_PersonelId",
                table: "StokHareketleris",
                column: "PersonelId");

            migrationBuilder.CreateIndex(
                name: "IX_StokHareketleris_StokId",
                table: "StokHareketleris",
                column: "StokId");

            migrationBuilder.CreateIndex(
                name: "IX_Stoks_DepoId",
                table: "Stoks",
                column: "DepoId");

            migrationBuilder.CreateIndex(
                name: "IX_Stoks_RafId",
                table: "Stoks",
                column: "RafId");

            migrationBuilder.CreateIndex(
                name: "IX_Stoks_UrunId",
                table: "Stoks",
                column: "UrunId");

            migrationBuilder.CreateIndex(
                name: "IX_Uruns_DepoId",
                table: "Uruns",
                column: "DepoId");

            migrationBuilder.CreateIndex(
                name: "IX_Uruns_KategoriId",
                table: "Uruns",
                column: "KategoriId");

            migrationBuilder.CreateIndex(
                name: "IX_Uruns_MusteriId",
                table: "Uruns",
                column: "MusteriId");

            migrationBuilder.CreateIndex(
                name: "IX_Uruns_OlcuBirimiId",
                table: "Uruns",
                column: "OlcuBirimiId");

            migrationBuilder.CreateIndex(
                name: "IX_Uruns_SiparisId",
                table: "Uruns",
                column: "SiparisId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DepoTedarikci");

            migrationBuilder.DropTable(
                name: "EnvanterUrun");

            migrationBuilder.DropTable(
                name: "EskiStokMiktaris");

            migrationBuilder.DropTable(
                name: "Images");

            migrationBuilder.DropTable(
                name: "SiparisStok");

            migrationBuilder.DropTable(
                name: "Tedarikcis");

            migrationBuilder.DropTable(
                name: "Envanters");

            migrationBuilder.DropTable(
                name: "StokHareketleris");

            migrationBuilder.DropTable(
                name: "EnvanterTipis");

            migrationBuilder.DropTable(
                name: "Personels");

            migrationBuilder.DropTable(
                name: "Stoks");

            migrationBuilder.DropTable(
                name: "Rafs");

            migrationBuilder.DropTable(
                name: "Uruns");

            migrationBuilder.DropTable(
                name: "Depos");

            migrationBuilder.DropTable(
                name: "Kategoris");

            migrationBuilder.DropTable(
                name: "OlcuBirimis");

            migrationBuilder.DropTable(
                name: "Siparises");

            migrationBuilder.DropTable(
                name: "Musteris");

            migrationBuilder.DropTable(
                name: "Sevkiyats");
        }
    }
}
