using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IImageRepository:IRepository<Image>
{
    Task<List<Image>> GetAktif();
    Task<List<Image>> GetFilterUrun(int? id);

}