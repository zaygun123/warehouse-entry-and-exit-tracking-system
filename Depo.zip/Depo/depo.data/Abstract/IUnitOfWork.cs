using depo.entity;
namespace depo.data.Abstract;
public interface IUnitOfWork:IDisposable
{
    IDepoRepository Depos {get;}
    IEnvanterRepository Envanters {get;}
    IEnvanterTipiRepository EnvanterTipis {get;}
    IImageRepository Images {get;}
    IKategoriRepository Kategoris {get;}
    IMusteriRepository Musteris {get;}
    IOlcuBirimiRepository OlcuBirimis {get;}
    IPersonelRepository Personels {get;}
    ISevkiyatRepository Sevkiyats {get;}
    ISiparisRepository Siparises {get;}
    IStokHareketleriRepository StokHareketleris {get;}
    IStokRepository Stoks {get;}
    ITedarikciRepository Tedarikcis {get;}
    IUrunRepository Uruns {get;}
    IRafRepository Rafs {get;}
    IEskiStokMiktariRepository EskiStokMiktaris {get;}
    void Save();
    Task<int> SaveAsync();
}