using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IDepoRepository:IRepository<Depo>
{
    Task<List<Depo>> GetAktif();
    Task UpdateGetWithTedarikci(Depo entity,List<int> tedarikci);
    Task<Depo> GetById(int id);
    Task<Depo> GetDepoWithTedarikci(int id);
    Task<Depo> GetFilterPersonel(int id);


}