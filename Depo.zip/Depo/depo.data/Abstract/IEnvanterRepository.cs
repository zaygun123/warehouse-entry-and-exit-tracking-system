using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IEnvanterRepository:IRepository<Envanter>
{
    Task<List<Envanter>> GetAktif();
    Task<List<Envanter>> GetFilterUrun(int? id);

}