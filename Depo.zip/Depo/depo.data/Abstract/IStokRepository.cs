using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IStokRepository:IRepository<Stok>
{
    Task<List<Stok>> GetAktif();
    Task<Stok> GetById(int id);
    Task<List<Stok>> GetFilterSiparis(int? id);
    Task<List<Stok>> GetStoksByRafId(int ? id);


}