using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IRafRepository:IRepository<Raf>
{
    Task<List<Raf>> GetAktif();
    Task<List<Raf>> GetRafsByDepoId(int? id);
    Task<Raf> GetFilterStok(int id);
}