using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IUrunRepository:IRepository<Urun>
{
    Task<List<Urun>> GetAktif();
    Task<Urun> GetById(int id);
    Task UpdateGetWithEnvanter(Urun entity,List<int> envanter);
    Task<Urun> GetUrunWithEnvanter(int id);

}