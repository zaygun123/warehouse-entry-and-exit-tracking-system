using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IPersonelRepository:IRepository<Personel>
{
    Task<List<Personel>> GetAktif();
    Task<Personel> GetById(int id);
    Task<Personel> GetFilterStokHareketleri(int id);

}