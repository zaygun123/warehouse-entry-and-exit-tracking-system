using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IEnvanterTipiRepository:IRepository<EnvanterTipi>
{
    Task<List<EnvanterTipi>> GetAktif();
}