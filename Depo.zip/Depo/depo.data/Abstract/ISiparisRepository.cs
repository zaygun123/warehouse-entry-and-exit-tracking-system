using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface ISiparisRepository:IRepository<Siparis>
{
    Task<List<Siparis>> GetAktif();
    Task<Siparis> GetById(int id);
    Task UpdateGetWithStok(Siparis entity,List<int> stok);
    Task<List<Siparis>> GetFilterSevkiyat(int? id);
    Task<Siparis> GetSiparisWithStok(int id);
    


}