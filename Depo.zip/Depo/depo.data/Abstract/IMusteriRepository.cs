using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IMusteriRepository:IRepository<Musteri>
{
    Task<List<Musteri>> GetAktif();
    Task<Musteri> GetFilterSiparis(int id);

}