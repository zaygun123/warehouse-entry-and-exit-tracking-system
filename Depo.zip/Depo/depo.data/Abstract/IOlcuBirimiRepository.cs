using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IOlcuBirimiRepository:IRepository<OlcuBirimi>
{
    Task<List<OlcuBirimi>> GetAktif();

}