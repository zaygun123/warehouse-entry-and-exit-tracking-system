using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface ITedarikciRepository:IRepository<Tedarikci>
{
    Task<List<Tedarikci>> GetAktif();
    Task<List<Tedarikci>> GetFilterDepo(int? id);

}