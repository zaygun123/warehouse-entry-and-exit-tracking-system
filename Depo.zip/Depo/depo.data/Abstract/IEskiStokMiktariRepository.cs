using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IEskiStokMiktariRepository:IRepository<EskiStokMiktari>
{
    Task<List<EskiStokMiktari>> GetAktif();
    Task<List<EskiStokMiktari>> GetsStokMiktariByStokId(int? stokId);
    Task<EskiStokMiktari> GetById(int? stokId);

}