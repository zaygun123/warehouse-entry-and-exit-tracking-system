using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface IStokHareketleriRepository:IRepository<StokHareketleri>
{
    Task<List<StokHareketleri>> GetAktif();
    Task<StokHareketleri> GetById(int id);
    Task<List<StokHareketleri>> GetStokHareketisByStokId(int ? id);
    Task<List<StokHareketleri>> GetStokHareketlerisByPersonelId(int? id);

}