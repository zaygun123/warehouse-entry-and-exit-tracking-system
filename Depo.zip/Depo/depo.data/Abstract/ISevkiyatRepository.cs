using System.Collections.Generic;
using System.Threading.Tasks;
using depo.entity;

namespace depo.data.Abstract;
public interface ISevkiyatRepository:IRepository<Sevkiyat>
{
    Task<List<Sevkiyat>> GetAktif();
    Task<Sevkiyat> GetFilterSiparis(int id);
}