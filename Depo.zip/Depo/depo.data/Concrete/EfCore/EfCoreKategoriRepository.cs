using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreKategoriRepository:EfCoreGenericRepository<Kategori>,IKategoriRepository
{
   public EfCoreKategoriRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Kategori>> GetAktif()
    {
        return await GeneralContext.Kategoris
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<Kategori> GetFilterUrun(int id)
    {
        return await GeneralContext.Kategoris
                        .Include(i=>i.Uruns)
                        .Where(x=>x.Id==id)
                        .SingleOrDefaultAsync();
    }
}