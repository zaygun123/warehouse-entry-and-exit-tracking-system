using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreSiparisRepository:EfCoreGenericRepository<Siparis>,ISiparisRepository
{
   public EfCoreSiparisRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Siparis>> GetAktif()
    {
        return await GeneralContext.Siparises
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<Siparis> GetById(int id)
    {
        return await GeneralContext.Siparises
                                .Where(i => i.Id == id && !i.Passive)
                                .Include(m => m.Musteri)
                                .Include(m => m.SiparisStoks)    
                                .Include(m=>m.Sevkiyat)
                                .FirstOrDefaultAsync();
    }
    public async Task UpdateGetWithStok(Siparis entity,List<int> stok)
    {
        var siparis =await GeneralContext.Siparises        
                                .Where(i=>i.Id==entity.Id)
                                .Include(i=>i.SiparisStoks)
                                    .ThenInclude(s => s.Stok)
                                        .ThenInclude(u => u.Urun)
                                .FirstOrDefaultAsync();
        if(siparis!=null)
        {
            siparis.SiparisStoks.Clear();
            foreach(var stokId in stok)
            {
                siparis.SiparisStoks.Add(new SiparisStok
                {
                    SiparisId=siparis.Id,
                    StokId=stokId,
                });
            }
            await _context.SaveChangesAsync();
        }
    }
    public async Task<List<Siparis>> GetFilterSevkiyat(int? sevkiyatId)
    {
        return await GeneralContext.Siparises
                            .Where(r => r.SevkiyatId == sevkiyatId && !r.Passive)
                            .ToListAsync();
    }
    public async Task<Siparis> GetSiparisWithStok(int id)
    {
        return await GeneralContext.Siparises
                            .Where(i => i.Id == id)
                            .Include(dt=>dt.SiparisStoks)
                                .ThenInclude(t=> t.Stok)
                            .FirstOrDefaultAsync();
    }

}