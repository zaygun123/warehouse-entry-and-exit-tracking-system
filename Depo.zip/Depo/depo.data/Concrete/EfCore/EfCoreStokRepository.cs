using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreStokRepository:EfCoreGenericRepository<Stok>,IStokRepository
{
   public EfCoreStokRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Stok>> GetAktif()
    {
        return await GeneralContext.Stoks
                                .Where(i=>!i.Passive)
                                .Include(i => i.Urun)
                                .ToListAsync();
    }
    public async Task<Stok> GetById(int id)
    {
        return await GeneralContext.Stoks
                                .Where(i => i.Id == id && !i.Passive)
                                .Include(k => k.Depo)
                                .Include(u=>u.Urun)
                                .Include(r=>r.Raf)
                                .Include(s=>s.StokHareketleris)
                                .Include(s=>s.EskiStokMiktaris)
                                .FirstOrDefaultAsync();
    }
    public async Task<List<Stok>> GetFilterSiparis(int? siparisId)
    {
        return await GeneralContext.Stoks
                                .Where(i=>!i.Passive)
                                .Where(stok => stok.SiparisStoks.Any(siparis => siparis.SiparisId == siparisId))
                                .Include(i=>i.Urun)
                                    .ThenInclude(o=>o.OlcuBirimi)
                                .ToListAsync();
    }
    public async Task<List<Stok>> GetStoksByRafId(int? rafId)
    {
        return await GeneralContext.Stoks
                            .Where(r => r.RafId == rafId && !r.Passive)
                            .Include(u => u.Urun)
                            .Include(s=>s.StokHareketleris)
                            .ToListAsync();
    }
}