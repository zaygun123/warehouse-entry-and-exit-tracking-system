using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreSevkiyatRepository:EfCoreGenericRepository<Sevkiyat>,ISevkiyatRepository
{
   public EfCoreSevkiyatRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Sevkiyat>> GetAktif()
    {
        return await GeneralContext.Sevkiyats
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<Sevkiyat> GetById(int id)
    {
        return await GeneralContext.Sevkiyats
                                .Where(i => i.Id == id && !i.Passive)
                                .Include(s=>s.Siparises)
                                .FirstOrDefaultAsync();
    }
    public async Task<Sevkiyat> GetFilterSiparis(int id)
    {
        return await GeneralContext.Sevkiyats
                        .Include(i=>i.Siparises)
                        .Where(x=>x.Id==id)
                        .SingleOrDefaultAsync();
    }
    
}