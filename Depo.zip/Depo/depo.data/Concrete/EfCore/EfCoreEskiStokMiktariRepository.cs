using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreEskiStokMiktariRepository:EfCoreGenericRepository<EskiStokMiktari>,IEskiStokMiktariRepository
{
   public EfCoreEskiStokMiktariRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<EskiStokMiktari>> GetAktif()
    {
        return await GeneralContext.EskiStokMiktaris
                                .Where(i=>i.Passive ==false)
                                .ToListAsync();
    }
    public async Task<List<EskiStokMiktari>> GetsStokMiktariByStokId(int? stokId)
    {
        return await GeneralContext.EskiStokMiktaris
                            .Where(r => r.StokId == stokId && !r.Passive)
                            .Include(s => s.Stok)
                            .ToListAsync();
    }
    public async Task<EskiStokMiktari> GetById(int? stokId)
    {
        return await GeneralContext.EskiStokMiktaris
                            .Where(r => r.StokId == stokId && !r.Passive)
                            .Include(s => s.Stok)
                            .FirstOrDefaultAsync();
    }

}