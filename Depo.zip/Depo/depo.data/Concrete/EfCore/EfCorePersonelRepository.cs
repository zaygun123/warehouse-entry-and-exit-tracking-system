using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCorePersonelRepository:EfCoreGenericRepository<Personel>,IPersonelRepository
{
   public EfCorePersonelRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Personel>> GetAktif()
    {
        return await GeneralContext.Personels
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<Personel> GetById(int id)
    {
        return await GeneralContext.Personels
                                .Where(i => i.Id == id && !i.Passive)
                                .Include(m => m.Depo)
                                .FirstOrDefaultAsync();
    }
    public async Task<Personel> GetFilterStokHareketleri(int id)
    {
        return await GeneralContext.Personels
                                .Include(i=>i.StokHareketleris)
                                .Where(i=>i.Id==id)
                                .SingleOrDefaultAsync();
    }
}