using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreImageRepository:EfCoreGenericRepository<Image>,IImageRepository
{
   public EfCoreImageRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Image>> GetAktif()
    {
        return await GeneralContext.Images
                                .Where(i=>i.Passive ==false)
                                .ToListAsync();
    }
    public async Task<List<Image>> GetFilterUrun(int? id)
    {
        return await GeneralContext.Images
                                .Where(i=>!i.Passive)
                                .Where(i => i.UrunId == id)
                                .ToListAsync();
    }
}