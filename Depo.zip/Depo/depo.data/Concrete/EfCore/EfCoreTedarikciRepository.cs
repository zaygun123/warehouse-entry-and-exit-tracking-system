using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreTedarikciRepository:EfCoreGenericRepository<Tedarikci>,ITedarikciRepository
{
   public EfCoreTedarikciRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Tedarikci>> GetAktif()
    {
        return await GeneralContext.Tedarikcis
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    
    public async Task<List<Tedarikci>> GetFilterDepo(int? depoId)
    {
        return await GeneralContext.Tedarikcis
                                .Where(i=>!i.Passive)
                                .Where(tedarikci => tedarikci.DepoTedarikcis.Any(depo => depo.DepoId == depoId))
                                .ToListAsync();
    }
    
}