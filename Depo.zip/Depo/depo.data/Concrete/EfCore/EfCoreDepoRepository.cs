using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreDepoRepository:EfCoreGenericRepository<Depo>,IDepoRepository
{
   public EfCoreDepoRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Depo>> GetAktif()
    {
        return await GeneralContext.Depos
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task UpdateGetWithTedarikci(Depo entity,List<int> tedarikci)
    {
        var depo =await GeneralContext.Depos        
                                .Where(i=>i.Id==entity.Id)
                                .Include(i=>i.DepoTedarikcis)
                                .FirstOrDefaultAsync();
        if(depo!=null)
        {
            depo.DepoTedarikcis.Clear();
            foreach(var tedarikciId in tedarikci)
            {
                depo.DepoTedarikcis.Add(new DepoTedarikci
                {
                    DepoId=depo.Id,
                    TedarikciId=tedarikciId
                });
            }
            await _context.SaveChangesAsync();
        }
    }
    public async Task<Depo> GetById(int id)
    {
        return await GeneralContext.Depos
                                .Where(i => i.Id == id  && !i.Passive)
                                .Include(i=>i.DepoTedarikcis)
                                .Include(r=>r.Rafs)
                                .FirstOrDefaultAsync();
    }
    public async Task<Depo> GetDepoWithTedarikci(int id)
    {
        return await GeneralContext.Depos
                            .Where(i => i.Id == id)
                            .Include(dt=>dt.DepoTedarikcis)
                                .ThenInclude(t=> t.Tedarikci)
                            .FirstOrDefaultAsync();
    }
    public async Task<Depo> GetFilterPersonel(int id)
    {
        return await GeneralContext.Depos
                           .Where(i=>i.Id==id)
                           .Include(P=>P.Personels)
                           .SingleOrDefaultAsync();
    }
    
}