using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using depo.data.Abstract;
namespace depo.data.Concrete.EfCore;
public class UnitOfWork:IUnitOfWork
{
    private readonly GeneralContext _context;
    public UnitOfWork(GeneralContext context)
    {
        _context=context;
    }
    private EfCoreDepoRepository _depoRepository;
    private EfCoreEnvanterRepository _envanterRepository;
    private EfCoreEnvanterTipiRepository _envantertipiRepository;
    private EfCoreImageRepository _imageRepository;
    private EfCoreKategoriRepository _kategoriRepository;
    private EfCoreMusteriRepository _musteriRepository;
    private EfCoreOlcuBirimiRepository _olcubirimiRepository;
    private EfCorePersonelRepository _personelRepository;
    private EfCoreSevkiyatRepository _sevkiyatRepository;
    private EfCoreSiparisRepository _siparisRepository;
    private EfCoreStokHareketleriRepository _stokhareketleriRepository;
    private EfCoreStokRepository _stokRepository;
    private EfCoreTedarikciRepository _tedarikciRepository;
    private EfCoreUrunRepository _urunRepository;
    private EfCoreRafRepository _rafRepository;
    private EfCoreEskiStokMiktariRepository _eskiStokMiktariRepository;

    public IDepoRepository Depos => 
        _depoRepository = _depoRepository ?? new EfCoreDepoRepository(_context);   
    public IEnvanterRepository Envanters => 
        _envanterRepository = _envanterRepository ?? new EfCoreEnvanterRepository(_context); 
    public IEnvanterTipiRepository EnvanterTipis => 
        _envantertipiRepository = _envantertipiRepository ?? new EfCoreEnvanterTipiRepository(_context);
    public IImageRepository Images => 
        _imageRepository = _imageRepository ?? new EfCoreImageRepository(_context);

    public IKategoriRepository Kategoris => 
        _kategoriRepository = _kategoriRepository ?? new EfCoreKategoriRepository(_context);
    public IMusteriRepository Musteris => 
        _musteriRepository = _musteriRepository ?? new EfCoreMusteriRepository(_context);
    public IOlcuBirimiRepository OlcuBirimis => 
        _olcubirimiRepository = _olcubirimiRepository ?? new EfCoreOlcuBirimiRepository(_context);
    public IPersonelRepository Personels => 
        _personelRepository = _personelRepository ?? new EfCorePersonelRepository(_context);
    public ISevkiyatRepository Sevkiyats => 
        _sevkiyatRepository = _sevkiyatRepository ?? new EfCoreSevkiyatRepository(_context);
    public ISiparisRepository Siparises => 
        _siparisRepository = _siparisRepository ?? new EfCoreSiparisRepository(_context);
    public IStokHareketleriRepository StokHareketleris => 
        _stokhareketleriRepository = _stokhareketleriRepository ?? new EfCoreStokHareketleriRepository(_context);
    public IStokRepository Stoks => 
        _stokRepository = _stokRepository ?? new EfCoreStokRepository(_context);
    public ITedarikciRepository Tedarikcis => 
        _tedarikciRepository = _tedarikciRepository ?? new EfCoreTedarikciRepository(_context);
    public IUrunRepository Uruns => 
        _urunRepository = _urunRepository ?? new EfCoreUrunRepository(_context);
    public IRafRepository Rafs => 
        _rafRepository = _rafRepository ?? new EfCoreRafRepository(_context);
    public IEskiStokMiktariRepository EskiStokMiktaris => 
        _eskiStokMiktariRepository = _eskiStokMiktariRepository ?? new EfCoreEskiStokMiktariRepository(_context);


    // public void Commit()
    // {
    //     _context.SaveChanges();
    // }
    // public async Task CommitAsync()
    // {
    //     await _context.SaveChangesAsync();
    // }
    public void Dispose()
    {
        _context.Dispose();
    }

    public void Save() 
    {
        _context.SaveChanges();
    }
    public async Task<int> SaveAsync()
    {
        return await _context.SaveChangesAsync();
    
    }
}