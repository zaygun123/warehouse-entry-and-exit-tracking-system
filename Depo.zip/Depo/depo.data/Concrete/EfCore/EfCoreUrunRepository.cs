using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreUrunRepository:EfCoreGenericRepository<Urun>,IUrunRepository
{
   public EfCoreUrunRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Urun>> GetAktif()
    {
        return await GeneralContext.Uruns
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<Urun> GetById(int id)
    {
        return await GeneralContext.Uruns
                                .Where(i => i.Id == id && !i.Passive)
                                .Include(k => k.Kategori)
                                .Include(o=>o.OlcuBirimi)
                                .Include(i=>i.EnvanterUruns)
                                .Include(i=>i.Stoks)
                                .FirstOrDefaultAsync();
    }
    public async Task UpdateGetWithEnvanter(Urun entity,List<int> envanter)
    {
        var urun =await GeneralContext.Uruns        
                                .Where(i=>i.Id==entity.Id)
                                .Include(i=>i.EnvanterUruns)
                                .FirstOrDefaultAsync();
        if(urun!=null)
        {
            urun.EnvanterUruns.Clear();
            foreach(var envanterId in envanter)
            {
                urun.EnvanterUruns.Add(new EnvanterUrun
                {
                    UrunId=urun.Id,
                    EnvanterId=envanterId
                });
            }
            await _context.SaveChangesAsync();
        }
    }
        public async Task<Urun> GetUrunWithEnvanter(int id)
    {
        return await GeneralContext.Uruns
                            .Where(i => i.Id == id)
                            .Include(dt=>dt.EnvanterUruns)
                                .ThenInclude(t=> t.Envanter)
                            .FirstOrDefaultAsync();
    }
}
