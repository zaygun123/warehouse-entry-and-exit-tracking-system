using System.Dynamic;
using depo.entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
namespace depo.data.Concrete.EfCore;

    public class GeneralContext : DbContext
    {
        public GeneralContext(DbContextOptions<GeneralContext>options):base(options)
        {
            
        }
        public DbSet<Depo> Depos { get; set; }
        public DbSet<Envanter> Envanters { get; set; }
        public DbSet<EnvanterTipi> EnvanterTipis { get; set; }
        public DbSet<Musteri> Musteris { get; set; }
        public DbSet<Sevkiyat> Sevkiyats { get; set; }
        public DbSet<Siparis> Siparises { get; set; }
        public DbSet<StokHareketleri> StokHareketleris { get; set; }
        public DbSet<Tedarikci> Tedarikcis { get; set; }
        public DbSet<Image> Images { get; set; }
        public DbSet<Kategori> Kategoris { get; set; }
        public DbSet<OlcuBirimi> OlcuBirimis { get; set; }
        public DbSet<Personel> Personels { get; set; }
        public DbSet<Stok> Stoks { get; set; }
        public DbSet<Urun> Uruns { get; set; }
        public DbSet<Raf> Rafs { get; set; }
        public DbSet<EskiStokMiktari> EskiStokMiktaris { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DepoTedarikci>()
            .HasKey(c=>new {c.DepoId,c.TedarikciId});
        
        modelBuilder.Entity<EnvanterUrun>()
            .HasKey(e=>new {e.EnvanterId,e.UrunId});
            
        modelBuilder.Entity<SiparisStok>()
            .HasKey(s=>new {s.SiparisId,s.StokId});
            
        modelBuilder.Entity<StokHareketleri>()
                .HasOne(sh => sh.EskiStokMiktari)
                .WithOne(em => em.StokHareketleri)
                .HasForeignKey<EskiStokMiktari>(em => em.StokHareketleriId); 
    }
}
