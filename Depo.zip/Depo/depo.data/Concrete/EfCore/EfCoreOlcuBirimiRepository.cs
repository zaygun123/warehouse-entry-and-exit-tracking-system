using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreOlcuBirimiRepository:EfCoreGenericRepository<OlcuBirimi>,IOlcuBirimiRepository
{
   public EfCoreOlcuBirimiRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<OlcuBirimi>> GetAktif()
    {
        return await GeneralContext.OlcuBirimis
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
}