using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using depo.data.Abstract;
using depo.entity;

namespace depo.data.Concrete.EfCore;
public class EfCoreMusteriRepository:EfCoreGenericRepository<Musteri>,IMusteriRepository
{
   public EfCoreMusteriRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Musteri>> GetAktif()
    {
        return await GeneralContext.Musteris
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<Musteri> GetFilterSiparis(int id)
    {
        return await GeneralContext.Musteris
                                .Include(i=>i.Siparises)
                                .Where(i=>i.Id==id)
                                .SingleOrDefaultAsync();
    }    

}