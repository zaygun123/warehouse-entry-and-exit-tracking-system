using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreStokHareketleriRepository:EfCoreGenericRepository<StokHareketleri>,IStokHareketleriRepository
{
   public EfCoreStokHareketleriRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<StokHareketleri>> GetAktif()
    {
        return await GeneralContext.StokHareketleris
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }

    public async Task<StokHareketleri> GetById(int id)
    {
        return await GeneralContext.StokHareketleris
                                .Where(i => i.Id == id && !i.Passive)
                                .Include(p=>p.Personel)
                                .Include(s=>s.EskiStokMiktari)
                                .Include(u=>u.Stok)
                                     .ThenInclude(u=>u.Urun)
                                .FirstOrDefaultAsync();
    }
    public async Task<List<StokHareketleri>> GetStokHareketisByStokId(int? stokId)
    {
        return await GeneralContext.StokHareketleris
                            .Where(r => r.StokId == stokId && !r.Passive)
                            .Include(p=>p.Personel)
                            .Include(e => e.EskiStokMiktari)
                            .ToListAsync();
    }
    public async Task<List<StokHareketleri>> GetStokHareketlerisByPersonelId(int? personelId)
    {
        return await GeneralContext.StokHareketleris
                            .Where(r => r.PersonelId == personelId && !r.Passive)
                            .Include(u => u.Stok)
                            .ToListAsync();
    }
    
}