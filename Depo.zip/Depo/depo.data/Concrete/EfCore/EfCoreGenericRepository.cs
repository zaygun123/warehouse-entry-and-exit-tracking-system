using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using depo.data.Abstract;
using Microsoft.EntityFrameworkCore;
namespace depo.data.Concrete.EfCore;
public class EfCoreGenericRepository<T>:IRepository<T> where T:class
{
    protected readonly GeneralContext _context;
    private readonly DbSet<T> _dbSet;

    public EfCoreGenericRepository(GeneralContext context)
    {
        _context=context;
        _dbSet=_context.Set<T>();
    }
    public void Create(T entity)
    {
        _context.Set<T>().Add(entity);
    }
    public async Task CreateAsync(T entity)
    {
        await _context.Set<T>().AddAsync(entity);
    }
    public async Task AddRangeAsync(IEnumerable<T> entities)
    {
        await _dbSet.AddRangeAsync(entities);
    }
    public void Delete(T entity)
    {
        _context.Set<T>().Remove(entity);
    }
    public async Task<List<T>> GetAll()
    {
        return await _context.Set<T>().ToListAsync();
    }
    public async Task<T> GetById(int id)
    {
        return await _context.Set<T>().FindAsync(id);
    }
    public void Update(T entity)
    {
        _context.Set<T>().Update(entity);
    }
}