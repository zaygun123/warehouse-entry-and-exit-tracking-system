using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreEnvanterRepository:EfCoreGenericRepository<Envanter>,IEnvanterRepository
{
   public EfCoreEnvanterRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Envanter>> GetAktif()
    {
        return await GeneralContext.Envanters
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<List<Envanter>> GetFilterUrun(int? urunId)
    {
        return await GeneralContext.Envanters
                                .Where(i=>!i.Passive)
                                .Where(envanter => envanter.EnvanterUruns.Any(urun => urun.UrunId == urunId))
                                .ToListAsync();
    }

}