using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreEnvanterTipiRepository:EfCoreGenericRepository<EnvanterTipi>,IEnvanterTipiRepository
{
   public EfCoreEnvanterTipiRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<EnvanterTipi>> GetAktif()
    {
        return await GeneralContext.EnvanterTipis
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
}