using depo.data.Abstract;
using depo.data.Concrete.EfCore;
using depo.entity;
using Microsoft.EntityFrameworkCore;

namespace depo.data.Concrete.EfCore;
public class EfCoreRafRepository:EfCoreGenericRepository<Raf>,IRafRepository
{
   public EfCoreRafRepository(GeneralContext context): base(context)
    {
        
    } 
    private GeneralContext GeneralContext{
        get{return _context as GeneralContext;}
    }
    public async Task<List<Raf>> GetAktif()
    {
        return await GeneralContext.Rafs
                                .Where(i=>!i.Passive)
                                .ToListAsync();
    }
    public async Task<List<Raf>> GetRafsByDepoId(int? depoId)
    {
        return await GeneralContext.Rafs
                            .Where(r => r.DepoId == depoId && !r.Passive)
                            .ToListAsync();
    }
    public async Task<Raf> GetFilterStok(int id)
    {
        return await GeneralContext.Rafs
                            .Include(i=>i.Stoks)
                            .Where(i=>i.Id==id)
                            .SingleOrDefaultAsync();
    }


}